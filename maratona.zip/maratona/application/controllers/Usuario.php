<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
		//$this->load->library('pagination');
		$this->load->model('Usuario_model', 'BDusuario');
		$this->load->model('Perfil_model', 'BDperfil');
		$this->load->model('Curso_model', 'BDcurso');
		$this->load->model('Modalidade_model', 'BDmodalidade');
		$this->load->model('Funcao_model', 'BDfuncao');
		$this->load->model('Requerimento_model', 'BDrequerimento');
		
	}

	public function index()
	{
	
	}
	
	public function alterar_senha(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') <= 9) 
			$permissao = 1;
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('usuario_altsenha_form');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
		
	public function gravar_alterar_senha(){
	
			$permissao = 0;
			
			if($this->session->userdata('PERFIL') <= 9) 
				$permissao = 1;	
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
			   $regras = array(
							  array(
									'field' => 'senha_atual',
									'label' => 'Senha Atual',
									'rules' => 'trim|required'
									),
							  array(
									'field' => 'nova_senha',
									'label' => 'Nova Senha',
									'rules' => 'trim|required|min_length[5]|max_length[16]'
									),							   
							  array(
									'field' => 'cnova_senha',
									'label' => 'Confirma Nova Senha',
									'rules' => 'trim|required|matches[nova_senha]'
									)						  
									
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
				   
				   //busca senha atual do usuario para comparacao
				   $id_usuario = $this->session->userdata('ID');
				   
				   $senha = $this->BDusuario->BuscaSenha($id_usuario);
				   
				   if(!strcmp(md5($this->input->post('senha_atual')), $senha['senha'])){
						//altera senha do usuario
						$dados_usuario = array(
							'senha_usuario' => md5($this->input->post('nova_senha'))
						);
						
						$this->BDusuario->EditarUsuario($id_usuario, $dados_usuario);
						
						$retorno["msg"] = "Senha alterada com sucesso!";
								 
						$this->load->view('success', $retorno);
				   }
				   else{
						$retorno["msg"] = "A senha não pode ser alterada, pois não confere com a atual.";
								 
						$this->load->view('alert', $retorno);				   
				   }
				   				   				   
			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				   
				$this->load->view('login', $msg);			
				
			}
			
	}	
	
	public function gravar_status(){

		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 5) || ($this->session->userdata('PERFIL') == 9) ) 
			$permissao = 1;		//se for o administrador ... secretaria ... cex
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$id = $this->input->post('id');

			$status = $this->BDusuario->TransacaoStatus($id);
			
			if ($status)
				echo "<i class='fa fa-toggle-on'></i> Ativo";
			else
				echo "<i class='fa fa-toggle-off'></i> Inativo";
						
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}	
		
	}	
	
	public function gravar_editar(){

			$permissao = 0;
			
			$dados['usuario'] = $this->BDusuario->PegaUsuarioEditar($this->input->post('id_usuario'));		
			
			if($dados['usuario']['codigo'] == $this->session->userdata('ID')){
				$permissao = 1;
			}elseif($this->session->userdata('PERFIL') == 1){ 
				$permissao = 1;
			}elseif( ($this->session->userdata('PERFIL') <= 4) && ($dados['usuario']['perfil'] >= $this->session->userdata('PERFIL')) ){
				$permissao = 1;
			}elseif( ($this->session->userdata('PERFIL') == 5) ){
			
				$curso_usuario = $dados['usuario']['curso'];
				$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
				
				foreach($curso_coordenador as $c){
					if ($c['curso'] == $curso_usuario){
						$permissao =  1;
					}
				}
	
			}elseif( ($this->session->userdata('PERFIL') == 9) && ($dados['usuario']['perfil'] >= 8) && ($dados['usuario']['perfil'] <= 9) ){
				$permissao = 1;
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			   $regras = array(
							  array(
									'field' => 'nome',
									'label' => 'Nome',
									'rules' => 'trim|required|max_length[80]'
									),
							  array(
									'field' => 'email',
									'label' => 'E-mail',
									'rules' => 'trim|valid_email|required|max_length[255]'
									),									
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
				    //cria vetor para encaminhar informações
				    $dados = array(
						  'nome_usuario' 	=> mb_strtoupper($this->input->post('nome'), 'UTF-8'),
						  'email_usuario'	=> $this->input->post('email'),
						);

					if($this->input->post('ativo'))
						$dados['ativo_usuario'] = $this->input->post('ativo');

					if($this->input->post('perfil'))
						$dados['id_perfil_usuario'] = $this->input->post('perfil');

					if($this->input->post('professor'))
						$dados['prof'] = $this->input->post('professor');
						
					if($this->input->post('senha'))
						$dados['senha_usuario'] = md5($this->input->post('senha'));						
						
					if($this->input->post('sexo'))
						$dados['sexo_usuario'] = $this->input->post('sexo');
					
					if($this->input->post('data_nascimento'))
						$dados['data_nasc_usuario'] = $this->BDfuncao->AjustaData($this->input->post('data_nascimento'));
					
					if($this->input->post('cpf'))
						$dados['cpf_usuario'] = $this->input->post('cpf');
					
					if($this->input->post('rg'))
						$dados['rg_usuario'] = $this->input->post('rg');
					
					if($this->input->post('telefone'))
						$dados['telefone_usuario'] = $this->input->post('telefone');
					
					if($this->input->post('whatsapp'))
						$dados['whatsapp_usuario'] = $this->input->post('whatsapp');
					
					if($this->input->post('curso'))
						$dados['id_curso_usuario'] = $this->input->post('curso');
					
					if($this->input->post('modalidade'))
						$dados['id_curso_modalidade_usuario'] = $this->input->post('modalidade');
					
					if($this->input->post('modulo_serie'))
						$dados['modulo_serie_curso_usuario'] = $this->input->post('modulo_serie');
					
					if($this->input->post('turno'))
						$dados['turno_curso_usuario'] = $this->input->post('turno');
			
			
				    $id = $this->BDusuario->TransacaoEditarUsuario($this->input->post('id_usuario'), $dados);
					
				    $retorno["msg"] = "Cadastro alterado com sucesso!";
				
				    $this->load->view('success_noreset', $retorno);
				 
			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				   
				$this->load->view('login', $msg);			
				
			}	
		
	}

	public function editar_perfil($id){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1){  //administrador
			$permissao = 1;
		}
	
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$dados['perfil'] = $this->BDperfil->Pega($id);
			
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('usuario_perfil_editar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}			
	
	public function editar($id){
	
		$permissao = 0;
		
		$dados['usuario'] = $this->BDusuario->PegaUsuarioEditar($id);		
		
		if($dados['usuario']['codigo'] == $this->session->userdata('ID')){
			$permissao = 1;
		}elseif($this->session->userdata('PERFIL') == 1){ 
			$permissao = 1;
		}elseif( ($this->session->userdata('PERFIL') <= 4) && ($dados['usuario']['perfil'] >= $this->session->userdata('PERFIL')) ){
			$permissao = 1;
		}elseif( ($this->session->userdata('PERFIL') == 5) ){
			
			$curso_usuario = $dados['usuario']['curso'];
			$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
			
			foreach($curso_coordenador as $c){
				if ($c['curso'] == $curso_usuario){
					$permissao =  1;
				}
			}

		}elseif( ($this->session->userdata('PERFIL') == 9) && ($dados['usuario']['perfil'] >= 8) && ($dados['usuario']['perfil'] <= 9) ){
			$permissao = 1;
		}
	
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$dados['perfil'] = $this->BDperfil->Listar();
			$dados['curso'] = $this->BDcurso->ListarCursos();
			$dados['modalidade'] = $this->BDcurso->ListarCursosModalidades();
		
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('usuario_editar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}			

	public function listar(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 5) || ($this->session->userdata('PERFIL') == 9) ) 
			$permissao = 1;		//se for o administrador ... secretaria ... coordenador ... cex
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['usuario'] = $this->BDusuario->ListarBuscarUsuarios($this->session->userdata('PERFIL'), $this->session->userdata('ID'));
		
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('usuario_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function listar_perfis(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1;		//se for o administrador
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['perfil'] = $this->BDusuario->ListarPerfisUsuario();
				
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('usuario_perfil_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
	
	public function inscrever(){
		
		$this->load->view('inscrever');
		
	}

	public function esqueci_senha(){
		
		$this->load->view('esqueceu_senha');
		
	}
	
	public function gravar_usuario(){
				
		$regras = array(
		  array(
				'field' => 'nome',
				'label' => 'Nome Completo',
				'rules' => 'trim|required|max_length[80]'
				),
		  array(
				'field' => 'email',
				'label' => 'E-mail',
				'rules' => 'trim|valid_email|required|max_length[255]'
				),						  
		  array(
				'field' => 'senha',
				'label' => 'Senha',
				'rules' => 'trim|required|max_length[255]'
				),						  
		  array(
				'field' => 'csenha',
				'label' => 'Confirma Senha',
				'rules' => 'trim|required|matches[senha]'
				)
		);

		$this->form_validation->set_rules($regras);
				
			   
	    if($this->form_validation->run() == FALSE)
		{
			
			$this->load->view('error_cadastro');
			
		}
	    else
	    {
		    //cria usuario com informações repassadas
		    //cria vetor para encaminhar informações
		   
		    /*Primeira checa se usuário com este e-mail existe para cadastrar */			
		   
		    if(!$this->BDusuario->ExisteUsuario($this->input->post('email'))){
		   
				$dados = array(
					  'nome_usuario' 	=> mb_strtoupper($this->input->post('nome'), 'UTF-8'),
					  'email_usuario'	=> $this->input->post('email'),
					  'senha_usuario'	=> md5($this->input->post('senha')),
					  'id_perfil_usuario' => 8	#aluno
					);
					

				$id = $this->BDusuario->TransacaoGravarUsuario($dados);
			   
				/*Após cadastro realiza entrada direta no sistema */
			   
				if ($id){
					
					echo '<form id="login" method="post" action="'.site_url('main').'">';
					echo '<input type="hidden" id="email" name="email" value="'.$this->input->post('email').'">';
					echo '<input type="hidden" id="senha" name="senha" value="'.$this->input->post('senha').'">';
					echo '</form>';
					
					echo '<script>';
					echo '$(function () {';
					echo "$('#login').submit();";
					echo '});';
					echo '</script>';
					
				}
			
			}
			else{
				
				echo '<div class="alert alert-warning alert-dismissible">';
				echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
				echo '<h4><i class="icon fa fa-warning"></i> Aten&ccedil;&atilde;o!</h4>';
				echo "Já existe um usuário cadastrado com este e-mail. Por favor, realize o <a href='". site_url()."'>login em sua conta</a>.";
				echo '</div>';

			}

	   }

	}

	public function gravar_nova_senha(){
				
		$regras = array(
		  array(
				'field' => 'id_usuario',
				'label' => 'ID usuário',
				'rules' => 'trim|required'
				),
		  array(
				'field' => 'senha_usuario',
				'label' => 'Senha usuário',
				'rules' => 'trim|required'
				),
   		  array(
				'field' => 'senha',
				'label' => 'Senha',
				'rules' => 'trim|required|max_length[255]'
				),						  
		  array(
				'field' => 'csenha',
				'label' => 'Confirma Senha',
				'rules' => 'trim|required|matches[senha]'
				)
		);

		$this->form_validation->set_rules($regras);
				
			   
	    if($this->form_validation->run() == FALSE)
		{
			
			$this->load->view('error_cadastro');
			
		}
	    else
	    {
		    //cria usuario com informações repassadas
		    //cria vetor para encaminhar informações
		   
		    $yes = $this->BDusuario->AutorizaRedefinirSenha($this->input->post('id_usuario'), $this->input->post('senha_usuario'));
			
			if($yes){
				
					$dados = array(
						'senha_usuario' => md5($this->input->post('senha'))
					);
					
					$id = $this->BDusuario->EditarUsuario($this->input->post('id_usuario'), $dados);
					
					$retorno['msg'] = "Senha alterada com sucesso!";
					
					$this->load->view('success_cadastro', $retorno);
					
			}
			else{

					echo '<div class="alert alert-warning alert-dismissible">';
					echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
					echo '<h4><i class="icon fa fa-warning"></i> Aten&ccedil;&atilde;o!</h4>';
					echo "Operação não autorizada.";
					echo '</div>';
				
			}

	   }

	}

	
	public function trocar_senha($codigo = "", $senha = ""){
		
		$yes = $this->BDusuario->AutorizaRedefinirSenha($codigo, $senha);
		
		if($yes){
			
			/*redefine senha do usuario */
			
			$dados['codigo'] = $codigo;
			$dados['senha'] = $senha;
			
			$this->load->view('redefine_senha', $dados);
			
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
		
	}


	public function redefinir_senha(){
				
		$regras = array(
		  array(
				'field' => 'email',
				'label' => 'E-mail',
				'rules' => 'trim|valid_email|required|max_length[255]'
				)
		);

		$this->form_validation->set_rules($regras);
				
			   
	    if($this->form_validation->run() == FALSE)
		{
			
			$this->load->view('error_cadastro');
			
		}
	    else
	    {
		    //cria usuario com informações repassadas
		    //cria vetor para encaminhar informações
		   
		    /*Primeira checa se usuário com este e-mail existe para cadastrar */		
		   
		    if($this->BDusuario->ExisteUsuario($this->input->post('email'))){
				
				/*envia e-mail para usuario, que fará a redefinição de senha */
				
				$dados['usuario'] = $this->BDusuario->RedefineSenhaUsuario($this->input->post('email'));
				
				$cfg = $this->BDfuncao->ConfigSystem();
				
				$this->load->library('email');
				
				$config['protocol'] = 'smtp';
				$config['smtp_host'] = $cfg['host_smtp'];
				$config['smtp_user'] = $cfg['email_smtp'];
				$config['smtp_pass'] = $cfg['senha_smtp'];
				$config['smtp_port'] = $cfg['port_smtp'];
				$config['smtp_crypto'] = $cfg['cripto_smtp'];
				$config['mailtype'] = 'html';
				$config['charset'] = 'utf-8';

				$this->email->initialize($config);
				
				$this->email->from($cfg['email_smtp'], 'IFNMG Pirapora');
				$this->email->to($dados['usuario']['email']);
				
				$this->email->subject('Redefinição de Senha - Sistema IFNMG Pirapora');
				
				$html = "<p>Olá " . $dados['usuario']['nome'] . "!</p>";
				$html.= "<p>Clique no link abaixo para redefinir sua senha:<br/>";
				$html.= "<a href='".site_url('usuario/trocar_senha/').$dados['usuario']['codigo']."/".$dados['usuario']['senha']."'>Redefinir Senha</a></p>";
				$html.= "<p>Atenciosamente,</p>";
				$html.= "<p>IFNMG Campus Pirapora</p>";
				
				$this->email->message($html);
				
				$this->email->send();

				/*Após enviar e-mail, mostrar msg na tela*/
				
				$retorno['msg'] = "Ok! Enviamos sua solicitação de redefinição de senha para o e-mail " . $this->input->post('email') . ".";
				
				$this->load->view('success_cadastro', $retorno);
			
			}
			else{
				
				echo '<div class="alert alert-warning alert-dismissible">';
				echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
				echo '<h4><i class="icon fa fa-warning"></i> Aten&ccedil;&atilde;o!</h4>';
				echo "E-mail não cadastrado!";
				echo '</div>';

			}

	   }

	}

	public function cadastrar_perfil(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1) 
			$permissao = 1;		//se for administrador
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
							
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('usuario_perfil_cadastrar_form');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}


	
	public function cadastrar(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 5) || ($this->session->userdata('PERFIL') == 9)) 
			$permissao = 1;		//se for administrador ... secretaria ... cex
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['perfil'] = $this->BDperfil->Listar();
			$dados['curso'] = $this->BDcurso->ListarCursos();
			$dados['modalidade'] = $this->BDcurso->ListarCursosModalidades();
							
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('usuario_cadastrar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function gravar_editar_perfil(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1; //se for administrador
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'nome_perfil',
								'label' => 'Nome do Perfil',
								'rules' => 'trim|required|max_length[100]'
								),
							array(
								'field' => 'codigo',
								'label' => 'Código do Perfil',
								'rules' => 'trim|required'
								),	
						  );
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {

			   //cria vetor para encaminhar informações
			   
				$dados = array(
					'tipo_perfil_usuario' => $this->input->post('nome_perfil'),
					'descricao_perfil_usuario' => $this->input->post('descricao_perfil'),
					);
					
			   $id = $this->BDperfil->Editar($this->input->post('codigo'), $dados);

			   $retorno["msg"] = "Cadastro alterado com sucesso!";
			   
			   $this->load->view('success', $retorno);

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


	public function gravar_perfil(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1; //se for administrador
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'nome_perfil',
								'label' => 'Nome do Perfil',
								'rules' => 'trim|required|max_length[100]'
								),
						  );
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {

			   //cria vetor para encaminhar informações
			   
				$dados = array(
					'tipo_perfil_usuario' => $this->input->post('nome_perfil'),
					'descricao_perfil_usuario' => $this->input->post('descricao_perfil'),
					);
					
			   $id = $this->BDperfil->Criar($dados);

			   $retorno["msg"] = "Cadastro efetuado com sucesso!";
			   
			   $this->load->view('success', $retorno);

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}
		
	public function gravar(){
	
			$permissao = 0;
			
			if( ($this->session->userdata('PERFIL') <= 5) || ($this->session->userdata('PERFIL') == 9) ) 
				$permissao = 1; //se for administrador ... secretaria
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			   $regras = array(
							  array(
									'field' => 'nome',
									'label' => 'Nome',
									'rules' => 'trim|required|max_length[80]'
									),
							  array(
									'field' => 'email',
									'label' => 'E-mail',
									'rules' => 'trim|valid_email|required|max_length[255]'
									),						  
							  array(
									'field' => 'senha',
									'label' => 'Senha',
									'rules' => 'trim|required|max_length[255]'
									),						  
							  array(
									'field' => 'ativo',
									'label' => 'Ativo',
									'rules' => 'trim|required'
									)						  
									
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
				   //cria usuario com informações repassadas
				   //cria vetor para encaminhar informações
				   
				    $dados = array(
						  'nome_usuario' 	=> mb_strtoupper($this->input->post('nome'), 'UTF-8'),
						  'email_usuario'	=> $this->input->post('email'),
						  'senha_usuario'	=> md5($this->input->post('senha')),
						  'ativo_usuario' 	=> $this->input->post('ativo'),
						  'id_perfil_usuario' => $this->input->post('perfil'),
						  'prof' => $this->input->post('professor')
						);
						
					if($this->input->post('sexo'))
						$dados['sexo_usuario'] = $this->input->post('sexo');
					
					if($this->input->post('data_nascimento'))
						$dados['data_nasc_usuario'] = $this->BDfuncao->AjustaData($this->input->post('data_nascimento'));
					
					if($this->input->post('cpf'))
						$dados['cpf_usuario'] = $this->input->post('cpf');
					
					if($this->input->post('rg'))
						$dados['rg_usuario'] = $this->input->post('rg');
					
					if($this->input->post('telefone'))
						$dados['telefone_usuario'] = $this->input->post('telefone');
					
					if($this->input->post('whatsapp'))
						$dados['whatsapp_usuario'] = $this->input->post('whatsapp');
					
					if($this->input->post('curso'))
						$dados['id_curso_usuario'] = $this->input->post('curso');
					
					if($this->input->post('modalidade'))
						$dados['id_curso_modalidade_usuario'] = $this->input->post('modalidade');
					
					if($this->input->post('modulo_serie'))
						$dados['modulo_serie_curso_usuario'] = $this->input->post('modulo_serie');
					
					if($this->input->post('turno'))
						$dados['turno_curso_usuario'] = $this->input->post('turno');	
	
				   $id = $this->BDusuario->TransacaoGravarUsuario($dados);

				   $retorno["msg"] = "Cadastro efetuado com sucesso!";
				   
				   $this->load->view('success', $retorno);

			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}
			
	}
	
	public function buscaArrayUsuario($id){
		
		$permissao = 0;
		
		$dados['usuario'] = $this->BDusuario->PegaUsuarioEditar($id);		
		
		if($dados['usuario']['codigo'] == $this->session->userdata('ID')){
			$permissao = 1;
		}elseif($this->session->userdata('PERFIL') == 1){ 
			$permissao = 1;
		}elseif( ($this->session->userdata('PERFIL') <= 4) && ($dados['usuario']['perfil'] >= $this->session->userdata('PERFIL')) ){
			$permissao = 1;
		}elseif( ($this->session->userdata('PERFIL') == 5) ){
			
			$curso_usuario = $dados['usuario']['curso'];
			$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
			
			foreach($curso_coordenador as $c){
				if ($c['curso'] == $curso_usuario){
					$permissao =  1;
				}
			}

		}elseif( ($this->session->userdata('PERFIL') == 9) && ($dados['usuario']['perfil'] >= 8) && ($dados['usuario']['perfil'] <= 9) ){
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			if (isset($id))
				
				echo '[' . json_encode($this->BDusuario->PegaUsuarioEditar($id)) . ']';
				
			else
			
				echo '[' . json_encode(array()) . ']';
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}	
	
}
