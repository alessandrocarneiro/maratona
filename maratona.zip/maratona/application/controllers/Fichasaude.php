<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fichasaude extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
        //$this->load->library('pagination');
        $this->load->model('Requerimento_model', 'BDrequerimento');
        // $this->load->model('Tipo_model', 'BDtipo');
        $this->load->model('Funcao_model', 'BDfuncao');
        $this->load->model('Usuario_model', 'BDusuario');
        // $this->load->model('Perfil_model', 'BDperfil');
        $this->load->model('Curso_model', 'BDcurso');
        $this->load->model('Modalidade_model', 'BDmodalidade');
		$this->load->model('Paciente_model', 'BDpaciente');
		$this->load->model('Fichasaude_model', 'BDficha');
        // $this->load->library('pdf');
	}

	public function index(){

	}

	public function cadastrar($id){
	
		$permissao = 0;

		$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

		//administrador e secretaria geral
		if( ($this->session->userdata('PERFIL') <= 2) ){ 
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
			$permissao = 1;
		}

		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
	
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));

			$dados['plano_saude'] = $this->BDpaciente->ListarPlanoSaude();
			$dados['grupo_sanguineo'] = $this->BDpaciente->ListarGrupoSanguineo();	
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_matricula_ficha_saude_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			
			$this->load->view('login', $msg);			
			
		}
	
	}	
	
	public function gravar(){
		
		$permissao = 0;

		$id = $this->input->post('codigo');

		$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

		//administrador e secretaria geral
		if( ($this->session->userdata('PERFIL') <= 2) ){ 
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
			$permissao = 1;
		}
				
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$regras = array(
							array(
								'field' => 'id_usuario',
								'label' => 'Nome',
								'rules' => 'trim|required'
							),
							array(
								'field' => 'codigo',
								'label' => 'Código do requerimento de matrícula',
								'rules' => 'trim|required'
							),

							);
									
			$this->form_validation->set_rules($regras);
			
			
			if($this->form_validation->run() == FALSE)
			{
			
				$this->load->view('error');
				
			}
			else
			{
			
				//cria vetor para encaminhar informações
				
				$id_paciente = $this->input->post('id_usuario');

				$config = $this->BDfuncao->ConfigSystem();
				
				$dados_ficha = array(
						'paciente_id' 	=> $this->input->post('id_usuario'),
						'campus_id' 		=> $config['id_campus_websaude'],
						'q1'				=> $this->input->post('q1_radio'),
						'q1_obs'			=> $this->input->post('q1_obs'),
						'q2'				=> $this->input->post('q2_radio'),
						'q2_obs'			=> $this->input->post('q2_obs'),
						'q3_catapora'		=> $this->input->post('q3_catapora'),
						'q3_meningite'	=> $this->input->post('q3_meningite'),
						'q3_hepatite'		=> $this->input->post('q3_hepatite'),
						'q3_dengue'		=> $this->input->post('q3_dengue'),
						'q3_pneumonia'	=> $this->input->post('q3_pneumonia'),
						'q3_bronquite'	=> $this->input->post('q3_bronquite'),
						'q3_rinite'		=> $this->input->post('q3_rinite'),
						'q3_caxumba'		=> $this->input->post('q3_caxumba'),
						'q3_sarampo'		=> $this->input->post('q3_sarampo'),
						'q3_rubeola'		=> $this->input->post('q3_rubeola'),
						'q3_difteria'		=> $this->input->post('q3_difteria'),
						'q3_outras'		=> $this->input->post('q3_outras'),
						'q3_obs'			=> $this->input->post('q3_obs'),
						'q4'				=> $this->input->post('q4_radio'),
						'q4_obs'			=> $this->input->post('q4_obs'),
						'q5'				=> $this->input->post('q5_radio'),
						'q5_obs'			=> $this->input->post('q5_obs'),
						'q6'				=> $this->input->post('q6_radio'),
						'q6_obs'			=> $this->input->post('q6_obs'),
						'q7'				=> $this->input->post('q7_radio'),
						'q7_obs'			=> $this->input->post('q7_obs'),
						'q71'				=> $this->input->post('q71_radio'),
						'q71_obs'			=> $this->input->post('q71_obs'),
						'q8'				=> $this->input->post('q8_radio'),
						'q8_obs'			=> $this->input->post('q8_obs'),
						'q8_obs2'			=> $this->input->post('q8_obs2'),
						'q9'				=> $this->input->post('q9_radio'),
						'q9_obs'			=> $this->input->post('q9_obs'),
						'q10'				=> $this->input->post('q10_radio'),
						'q11'				=> $this->input->post('q11_radio'),
						'q11_obs'			=> $this->input->post('q11_obs'),
						'q12'				=> $this->input->post('q12_radio'),
						'q12_obs'			=> $this->input->post('q12_obs'),
						'q13'				=> $this->input->post('q13_radio'),
						'q131'			=> $this->input->post('q131_radio'),
						'q131_obs'		=> $this->input->post('q131_obs'),
						'q14'				=> $this->input->post('q14_radio'),
						'q141'			=> $this->input->post('q141_radio'),
						'q141_obs'		=> $this->input->post('q141_obs'),
						'q15'				=> $this->input->post('q15_radio'),
						'q15_obs'			=> $this->input->post('q15_obs'),
						'q16'				=> $this->input->post('q16_radio'),
						'q16_obs'			=> $this->input->post('q16_obs'),
						'q17'				=> $this->input->post('q17_radio'),
						'q17_obs'			=> $this->input->post('q17_obs'),
						'q18'				=> $this->input->post('q18_radio'),
						'q18_obs'			=> $this->input->post('q18_obs'),
						'q19'				=> $this->input->post('q19_radio'),
						'q19_obs'			=> $this->input->post('q19_obs'),
						'q19_obs2'		=> $this->input->post('q19_obs2'),
						'q19_obs3'		=> $this->input->post('q19_obs3'),					  
						'q20_psicologo'	=> $this->input->post('q20_psicologo'),
						'q20_fonoaudiologo'=> $this->input->post('q20_fonoaudiologo'),
						'q20_terapia'		=> $this->input->post('q20_terapia'),
						'q20_outros'		=> $this->input->post('q20_outros'),
						'q20_obs'			=> $this->input->post('q20_obs'),
						'q22_enxergar'	=> $this->input->post('q22_enxergar'),
						'q22_falar'		=> $this->input->post('q22_falar'),
						'q22_ouvir'		=> $this->input->post('q22_ouvir'),
						'q22_andar'		=> $this->input->post('q22_andar'),
						'q22_movbracos'	=> $this->input->post('q22_movbracos'),
						'q22_movpernas'	=> $this->input->post('q22_movpernas'),
						'q23'				=> $this->input->post('q23_radio'),
						'q23_obs'			=> $this->input->post('q23_obs'),
						'data_hora_ficha_saude' => date('Y-m-d H:i:s')
						);
				
				$dados_paciente = array(
					'observacoes_paciente' => $this->input->post('q21_observacoes'),
					'data_atualiza_paciente' => date('Y-m-d H:i:s'),
					'doc_ficha_saude'	=> 1,
					'cartao_sus_paciente'	=> $this->input->post('cartao_sus'),
				);

				//linhas adicionadas para atualização das informações do usuário

				if($this->input->post('grupo_sanguineo')){
					$dados_paciente['grupo_sanguineo_id'] = $this->input->post('grupo_sanguineo');
				}

				if($this->input->post('plano_saude')){
					$dados_paciente['plano_saude_id'] = $this->input->post('plano_saude');
				}

				if($this->input->post('calendario_vacinal')){
					$dados_paciente['calendario_vacinal_paciente'] = $this->input->post('calendario_vacinal');
				}

				$dados_peso_altura = array();

				if( ($this->input->post('peso')) && ($this->input->post('altura'))){
					$dados_peso_altura['paciente_id'] = $id_paciente;
					$dados_peso_altura['peso_paciente'] = $this->input->post('peso');
					$dados_peso_altura['altura_paciente'] = $this->input->post('altura');

					if($this->input->post('imc_field')){
						$dados_peso_altura['imc_paciente'] = $this->input->post('imc_field');
					}

					$dados_peso_altura['data_peso_altura_paciente'] = date('Y-m-d H:i:s');
				}

				////
										
				$id_ficha = $this->BDficha->GravarFichaSaude($id_paciente, $dados_ficha, $dados_paciente, $dados_peso_altura);

				/// Linhas adicionadas para atualizar sistema websaude

				$paciente = $this->BDusuario->PegaUsuarioEditar($id_paciente);

				$postRequest = array(
					'auth' 			=> sha1($paciente['nome']),
					'nome'			=> $paciente['nome'],
					'cpf'			=> $paciente['cpf'],
					'plano_saude'	=> $paciente['plano_saude_id'],
					'cartao_sus'	=> $paciente['cartao_sus_paciente'],
					'sexo'			=> $paciente['sexo'],
					'grupo_sanguineo' => $paciente['grupo_sanguineo_id'],
					'telefone'		=> $paciente['telefone'],
					'email'			=> $paciente['email'],
					'endereco'		=> $paciente['endereco_usuario'],
					'bairro'		=> null,
					'cidade'		=> $this->BDrequerimento->getCidadeEstado($paciente['cidade_usuario'], 1),
					'uf'			=> $this->BDrequerimento->getCidadeEstado($paciente['cidade_usuario'], 2),
					'cep'			=> null,
					'observacoes'	=> $paciente['observacoes_paciente'],
					'rg'			=> $paciente['rg'],
					'org_exp_rg'	=> $paciente['orgao_expedidor_rg'],
					'calendario_vacinal' => $paciente['calendario_vacinal_paciente'],
					'emergencia'	=> null,
					'data_nasc'		=> $paciente['data_nascimento'],
					'data_exp_rg'	=> $paciente['data_expedicao_rg'],
					'nome_pai'		=> $paciente['filiacao_pai'],
					'telefone_pai'	=> null,
					'nome_mae'		=> $paciente['filiacao_mae'],
					'telefone_mae'	=> null,
					'peso'			=> $this->input->post('peso'),
					'altura'		=> $this->input->post('altura'),
					'imc_field'		=> $this->input->post('imc_field'),
					'campus'		=> $config['id_campus_websaude'],
					'curso'			=> $this->BDcurso->getCurso($paciente['curso']), //enviar nome do curso para pesquisa
					'modalidade'	=> $this->BDmodalidade->getModalidade($paciente['modalidade']), //enivar nome da modalidade para pesquisa
					'ingresso_sem'	=> $config['ingresso_sem_websaude'],
					'ingresso_ano'	=> $config['ingresso_ano_websaude'],
					'q1_radio'		=> $this->input->post('q1_radio'),
					'q1_obs'		=> $this->input->post('q1_obs'),
					'q2_radio'		=> $this->input->post('q2_radio'),
					'q2_obs'		=> $this->input->post('q2_obs'),
					'q3_catapora'	=> $this->input->post('q3_catapora'),
					'q3_meningite'	=> $this->input->post('q3_meningite'),
					'q3_hepatite'	=> $this->input->post('q3_hepatite'),
					'q3_dengue'		=> $this->input->post('q3_dengue'),
					'q3_pneumonia'	=> $this->input->post('q3_pneumonia'),
					'q3_bronquite'	=> $this->input->post('q3_bronquite'),
					'q3_rinite'		=> $this->input->post('q3_rinite'),
					'q3_caxumba'	=> $this->input->post('q3_caxumba'),
					'q3_sarampo'	=> $this->input->post('q3_sarampo'),
					'q3_rubeola'	=> $this->input->post('q3_rubeola'),
					'q3_difteria'	=> $this->input->post('q3_difteria'),
					'q3_outras'		=> $this->input->post('q3_outras'),
					'q3_obs'		=> $this->input->post('q3_obs'),
					'q4_radio'		=> $this->input->post('q4_radio'),
					'q4_obs'		=> $this->input->post('q4_obs'),
					'q5_radio'		=> $this->input->post('q5_radio'),
					'q5_obs'		=> $this->input->post('q5_obs'),
					'q6_radio'		=> $this->input->post('q6_radio'),
					'q6_obs'		=> $this->input->post('q6_obs'),
					'q7_radio'		=> $this->input->post('q7_radio'),
					'q7_obs'		=> $this->input->post('q7_obs'),
					'q71_radio'		=> $this->input->post('q71_radio'),
					'q71_obs'		=> $this->input->post('q71_obs'),
					'q8_radio'		=> $this->input->post('q8_radio'),
					'q8_obs'		=> $this->input->post('q8_obs'),
					'q8_obs2'		=> $this->input->post('q8_obs2'),
					'q9_radio'		=> $this->input->post('q9_radio'),
					'q9_obs'		=> $this->input->post('q9_obs'),
					'q10_radio'		=> $this->input->post('q10_radio'),
					'q11_radio'		=> $this->input->post('q11_radio'),
					'q11_obs'		=> $this->input->post('q11_obs'),
					'q12_radio'		=> $this->input->post('q12_radio'),
					'q12_obs'		=> $this->input->post('q12_obs'),
					'q13_radio'		=> $this->input->post('q13_radio'),
					'q131_radio'	=> $this->input->post('q131_radio'),
					'q131_obs'		=> $this->input->post('q131_obs'),
					'q14_radio'		=> $this->input->post('q14_radio'),
					'q141_radio'	=> $this->input->post('q141_radio'),
					'q141_obs'		=> $this->input->post('q141_obs'),
					'q15_radio'		=> $this->input->post('q15_radio'),
					'q15_obs'		=> $this->input->post('q15_obs'),
					'q16_radio'		=> $this->input->post('q16_radio'),
					'q16_obs'		=> $this->input->post('q16_obs'),
					'q17_radio'		=> $this->input->post('q17_radio'),
					'q17_obs'		=> $this->input->post('q17_obs'),
					'q18_radio'		=> $this->input->post('q18_radio'),
					'q18_obs'		=> $this->input->post('q18_obs'),
					'q19_radio'		=> $this->input->post('q19_radio'),
					'q19_obs'		=> $this->input->post('q19_obs'),
					'q19_obs2'		=> $this->input->post('q19_obs2'),
					'q19_obs3'		=> $this->input->post('q19_obs3'),					  
					'q20_psicologo'	=> $this->input->post('q20_psicologo'),
					'q20_fonoaudiologo'=> $this->input->post('q20_fonoaudiologo'),
					'q20_terapia'	=> $this->input->post('q20_terapia'),
					'q20_outros'	=> $this->input->post('q20_outros'),
					'q20_obs'		=> $this->input->post('q20_obs'),
					'q22_enxergar'	=> $this->input->post('q22_enxergar'),
					'q22_falar'		=> $this->input->post('q22_falar'),
					'q22_ouvir'		=> $this->input->post('q22_ouvir'),
					'q22_andar'		=> $this->input->post('q22_andar'),
					'q22_movbracos'	=> $this->input->post('q22_movbracos'),
					'q22_movpernas'	=> $this->input->post('q22_movpernas'),
					'q23_radio'		=> $this->input->post('q23_radio'),
					'q23_obs'		=> $this->input->post('q23_obs'),
					'q21_observacoes' => $this->input->post('q21_observacoes'),
				);

				$cURLConnection = curl_init($config['url_websaude'] . 'index.php/paciente/gravar_paciente_ficha_ws');
				curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
				curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
				
				$apiResponse = curl_exec($cURLConnection);
				curl_close($cURLConnection);
				
				// $apiResponse - available data from the API request
				$jsonArrayResponse = json_decode($apiResponse);

				/////////////////////////////////////////////////////
				
				$retorno["msg"] = "Cadastro efetuado com sucesso!";
				
				$this->load->view('success_desabilita_gravar', $retorno);
								
			}
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
				
			$this->load->view('login', $msg);			
			
		}	

	}


}
