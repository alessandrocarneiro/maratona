<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Requerimento extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
        //$this->load->library('pagination');
        $this->load->model('Requerimento_model', 'BDrequerimento');
        $this->load->model('Tipo_model', 'BDtipo');
        $this->load->model('Funcao_model', 'BDfuncao');
        $this->load->model('Usuario_model', 'BDusuario');
        $this->load->model('Perfil_model', 'BDperfil');
        $this->load->model('Curso_model', 'BDcurso');
        $this->load->model('Modalidade_model', 'BDmodalidade');
        $this->load->library('pdf');
	}

		public function index(){
		}

		public function gravar_status_mensagem(){

			$permissao = 1;
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id = $this->input->post('id');

				$status = $this->BDrequerimento->TransacaoStatusMensagem($id, $this->session->userdata('ID'));
				
				if ($status)
					echo "<i class='fa fa-check-circle'></i> Lida";
				else
					echo "<a href='#s' class='status' title='Marcar como mensagem lida' id='{$id}'><i class='fa fa-circle-o'></i> Não Lida</a>";
							
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}

		public function enviar_mensagem(){

			$permissao = 0;

			if($this->input->post('id_usuario_remetente') == $this->session->userdata('ID')){
				$permissao = 1;
			}

			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				$regras = array(
					array(
						'field' => 'id_requerimento',
						'label' => 'ID Requerimento',
						'rules' => 'trim|required'
						),
					array(
						'field' => 'id_usuario_remetente',
						'label' => 'ID Usuário Remetente',
						'rules' => 'trim|required'
						),
					array(
						'field' => 'id_usuario_destinatario',
						'label' => 'ID Usuário Destinatário',
						'rules' => 'trim|required'
						),
				
					array(
						'field' => 'mensagem',
						'label' => 'Mensagem',
						'rules' => 'trim|required'
						)
					);
										
				$this->form_validation->set_rules($regras);
				
				
				if($this->form_validation->run() == FALSE)
				{
				
					$this->load->view('error');
					
				}
				else
				{
					
					//cria vetor para encaminhar informações

					$dados_mensagem = array(
						'mensagem'				=> $this->input->post('mensagem'),
						'id_requerimento'		=> $this->input->post('id_requerimento'),
						'id_usuario_remetente'	=> $this->input->post('id_usuario_remetente'),
						'perfil_usuario_remetente'	=> $this->input->post('perfil_usuario_remetente'),
						'id_usuario_destinatario'	=> $this->input->post('id_usuario_destinatario'),
						'data_hora_envio'	=> date("Y-m-d H:i:s")
					);


					if($this->input->post('local_msg'))
						$dados_mensagem['local_msg'] = $this->input->post('local_msg');


					$id = $this->BDrequerimento->TransacaoGravarMensagem($dados_mensagem);

					/// se for requerimento de estágio
					if($this->input->post('local_msg') == 'RE'){
						/// se for diferente de aluno e extensão
						if(($this->input->post('perfil_usuario_remetente') != 8) && ($this->input->post('perfil_usuario_remetente') != 9)){
							// enviar msg para extensão
							$this->BDrequerimento->TransacaoGravarMensagemExtensao($dados_mensagem);
						}
						
					}					

					$retorno["msg"] = "Mensagem enviada com sucesso!";
					
					$this->load->view('success_reset2', $retorno);

					$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($this->input->post('id_requerimento'));

					$this->load->view('requerimento_editar_mensagens', $dados);

				}
				
			} else{

				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}

		}
		
		public function autorizar_menor(){

			$permissao = 0;
			
			if(($this->session->userdata('PERFIL') == 3) || ($this->session->userdata('PERFIL') == 4)) 
				$permissao = 1;		//se for secretaria
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');

				$status = $this->BDrequerimento->TransacaoAutorizarMenor($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo '<center><img src="'. base_url("application/views/") .'img/aprovado.png" width="32" title="Autorizado"></center>';
				}
				else{
					
					echo '<center><a href="javascript:autorizar_menor('.$id_requerimento.');">';
					echo '<img src="'. base_url("application/views/") .'img/atencao.png" width="32" title="Clique para Autorizar">';
					echo '</a></center>';				
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}		

		public function conceder_nada_consta(){

			$permissao = 0;
			
			if($this->session->userdata('PERFIL') == 7) 
				$permissao = 1;		//se for biblioteca
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');
				$valor_nc = $this->input->post('valor_nc');

				$status = $this->BDrequerimento->TransacaoConcederNadaConsta($id_requerimento, $id_usuario_autorizador, $valor_nc);
				
				if ($status == 1){
					echo '<center><img src="'. base_url("application/views/") .'img/aprovado.png" width="32" title="Nada Consta OK"></center>';
				}
				elseif ($status == -1){
					echo '<center><a href="javascript:conceder_nada_consta('.$id_requerimento.');">';
					echo '<img src="'. base_url("application/views/") .'img/pare.png" width="32" title="Clique para Conceder Nada Consta">';
					echo '</a></center>';				
				}
				else{
					echo '<center><a href="javascript:conceder_nada_consta('.$id_requerimento.');">';
					echo '<img src="'. base_url("application/views/") .'img/atencao.png" width="32" title="Clique para Conceder Nada Consta">';
					echo '</a></center>';				
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function conceder_seguro(){

			$permissao = 0;
			
			if($this->session->userdata('PERFIL') == 9) 
				$permissao = 1;		//se for cex
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');

				$status = $this->BDrequerimento->TransacaoConcederSeguro($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo '<center><img src="'. base_url("application/views/") .'img/aprovado.png" width="32" title="Seguro OK"></center>';
				}
				else{
					
					echo '<center><a href="javascript:conceder_seguro('.$id_requerimento.');">';
					echo '<img src="'. base_url("application/views/") .'img/atencao.png" width="32" title="Clique para conceder seguro institucional">';
					echo '</a></center>';				
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}
		
		public function atestar_declaracao_matricula(){

			$permissao = 0;
			
			if($this->session->userdata('PERFIL') == 9) 
				$permissao = 1;		//se for cex
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');

				$status = $this->BDrequerimento->TransacaoAtestarDeclaracao($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'OK';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:atestar_declaracao_matricula('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="atestar_declaracao_matricula"><i class="fa fa-thumbs-o-up"></i>  Atestar Declaração</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}		

		public function autorizar_estagio(){

			$permissao = 0;
			
			if($this->session->userdata('PERFIL') == 9) 
				$permissao = 1;		//se for cex
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');

				$status = $this->BDrequerimento->TransacaoAutorizarEstagio($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'OK';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:autorizar_estagio('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="autorizar_estagio"><i class="fa fa-thumbs-o-up"></i>  Autorizar Estágio</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function arquivar_estagio(){

			$permissao = 0;
			
			if($this->session->userdata('PERFIL') == 9) 
				$permissao = 1;		//se for cex
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$id_requerimento = $this->input->post('id');
				$id_usuario_autorizador = $this->input->post('id_autorizador');

				$status = $this->BDrequerimento->TransacaoArquivarEstagio($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'Sim';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:arquivar_estagio('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="arquivar_estagio"><i class="fa fa-thumbs-o-up"></i>  Confirmar Arquivamento</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function anuencia_coordenador(){

			$permissao = 0;

			$id_requerimento = $this->input->post('id');
			$id_usuario_autorizador = $this->input->post('id_autorizador');

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($this->BDrequerimento->getIdRequerimentoEstagio($id_requerimento));

			if ( ($this->session->userdata('PERFIL') == 5) ){

				$curso_usuario = $dados['requerimento']['id_curso'];
				$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($id_usuario_autorizador);

				foreach($curso_coordenador as $c){
					if ($c['curso'] == $curso_usuario){
						$permissao =  1;
					}
				}

			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$status = $this->BDrequerimento->TransacaoAnuenciaCoordenador($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'OK';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:anuencia_coordenador('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="anuencia_coordenador"><i class="fa fa-thumbs-o-up"></i>  Autorizar Estágio</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function anuencia_professor(){

			$permissao = 0;

			$id_requerimento = $this->input->post('id');
			$id_usuario_autorizador = $this->input->post('id_autorizador');

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($this->BDrequerimento->getIdRequerimentoEstagio($id_requerimento));
			
			if($dados['requerimento']['id_usuario_professor'] == $id_usuario_autorizador) 
				$permissao = 1;		//se for o professor
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$status = $this->BDrequerimento->TransacaoAnuenciaProfessor($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'OK';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:anuencia_professor('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="anuencia_professor"><i class="fa fa-thumbs-o-up"></i>  Autorizar Estágio</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function finalizado_professor(){

			$permissao = 0;

			$id_requerimento = $this->input->post('id');
			$id_usuario_autorizador = $this->input->post('id_autorizador');

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($this->BDrequerimento->getIdRequerimentoEstagio($id_requerimento));
			
			if($dados['requerimento']['id_usuario_professor'] == $id_usuario_autorizador) 
				$permissao = 1;		//se for o professor
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$status = $this->BDrequerimento->TransacaoFinalizadoProfessor($id_requerimento, $id_usuario_autorizador);
				
				if ($status){
					echo 'OK';
				}
				else{
					echo 'Não';
					echo '<a href="javascript:finalizado_professor('.$id_requerimento.');">';
					echo '<button type="button" class="btn btn-primary" id="finalizado_professor"><i class="fa fa-thumbs-o-up"></i>  Finalizar Estágio</button>';
					echo '</a>';
				}

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}	
			
		}	

		public function editar($id){
		
			$permissao = 0;

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEditar($id);
			
			if($this->session->userdata('PERFIL') <= 2){
				$permissao = 1;		//se for o administrador ... secretaria
			}
			elseif($this->session->userdata('PERFIL') == 3){

				if ( ($this->BDcurso->getAtendimento($dados['requerimento']['id_curso']) == "CRA") || ($this->BDcurso->getAtendimento($dados['requerimento']['id_curso']) == "") )
					$permissao = 1;

			}
			elseif($this->session->userdata('PERFIL') == 4){

				if ( ($this->BDcurso->getAtendimento($dados['requerimento']['id_curso']) == "CRE")  || ($this->BDcurso->getAtendimento($dados['requerimento']['id_curso']) == "") )
					$permissao = 1;

			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
				$dados['tipo_requerimento'] = $this->BDrequerimento->ListarTipoRequerimento(0);
				
				$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id);

				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
        
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_geral_editar', $dados);
				$this->load->view('main_footer');

				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
	}		

	public function editar_tipo($id){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1){
			$permissao = 1;		//se for o administrador 
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['tipo'] = $this->BDtipo->Pega($id);
			
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_tipo_editar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function visualizar_matricula($id, $id_msg = 0){
		
		$permissao = 0;

		$id = $this->BDrequerimento->getIdRequerimentoMatricula($id);

		$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

		//administrador e secretaria geral
		if( ($this->session->userdata('PERFIL') <= 2) ){ 
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){

			if($id_msg){
				$this->BDrequerimento->TransacaoLerMensagem($id_msg, $this->session->userdata('ID'));
			}

			$id_requerimento = $dados['requerimento']['id_requerimento'];

			$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id_requerimento);

			$dados['naturalidade'] = $this->BDrequerimento->getCidade($dados['requerimento']['naturalidade']);
			$dados['cidade_usuario'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_usuario']);
			$dados['cidade_curso_anterior'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_curso_anterior']);

			$dados['curso'] = $this->BDcurso->ListarCursos();
			$dados['modalidade'] = $this->BDcurso->ListarCursosModalidades();

			$dados['usuarios_secretaria'] = $this->BDusuario->ListarUsuariosMensagemSecretaria($dados['requerimento']['id_curso']);

			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_matricula_visualizar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function editar_resposta($id){
		
		$permissao = 0;

		$dados['requerimento'] = $this->BDrequerimento->PegaRespostaEditar($id);

		//administrador e secretaria geral
		if( ($this->session->userdata('PERFIL') == 1) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('editar_resposta', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			
			$this->load->view('login', $msg);			
			
		}
	
	}		


	public function editar_matricula($id){
		
		$permissao = 0;

		$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

		//administrador e secretaria geral
		if( ($this->session->userdata('PERFIL') <= 2) ){ 
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){

			$id_requerimento = $dados['requerimento']['id_requerimento'];

			$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id_requerimento);

			$dados['naturalidade'] = $this->BDrequerimento->getCidade($dados['requerimento']['naturalidade']);
			$dados['cidade_usuario'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_usuario']);
			$dados['cidade_curso_anterior'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_curso_anterior']);

			$dados['curso'] = $this->BDcurso->ListarCursos();
			$dados['modalidade'] = $this->BDcurso->ListarCursosModalidades();

			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_matricula_editar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			
			$this->load->view('login', $msg);			
			
		}
	
	}		


		public function editar_estagio($id){
		
			$permissao = 0;

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($id);

			//administrador e CEX
			
			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 9) ){ 
				$permissao = 1;
			}

			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
				$dados['tipo_requerimento'] = $this->BDrequerimento->ListarTipoRequerimento(0);

				$id_requerimento = $dados['requerimento']['id_requerimento'];

				$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id_requerimento);

				$dados['professor'] = $this->BDusuario->ListarProfessores();

				$dados['cidade_entidade'] = $this->BDrequerimento->getCidade($dados['requerimento']['id_cidade_entidade_estagio']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_coordenador']))
					$dados['nome_coordenador_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_coordenador']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_professor']))
					$dados['nome_professor_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_professor']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_finalizado']))
					$dados['nome_professor_anuencia_finalizado'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_finalizado']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_cex']))
					$dados['nome_cex_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_cex']);

				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
			
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_estagio_editar', $dados);
				$this->load->view('main_footer');
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}	

		public function visualizar_estagio($id, $id_msg = 0){
		
			$permissao = 0;
			$coordenador = 0;

			$id = $this->BDrequerimento->getIdRequerimentoEstagio($id);

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($id);

			//administrador, NAE (secretaria geral), aluno e CEX
			
			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 2) || ($this->session->userdata('PERFIL') == 9) ){ 
				$permissao = 1;
			}
			elseif($this->session->userdata('ID') == $dados['requerimento']['id_usuario_professor']){
				$permissao = 1;
			}
			elseif($this->session->userdata('PERFIL') == 8){

				if($this->session->userdata('ID') == $dados['requerimento']['id_usuario'])
					$permissao = 1;

			}
			if( ($this->session->userdata('PERFIL') == 5) ){
				$curso_usuario = $dados['requerimento']['id_curso'];
				$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
				
				foreach($curso_coordenador as $c){
					if ($c['curso'] == $curso_usuario){
						$permissao =  1;
						$coordenador = 1;
					}
				}
				
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				if($id_msg){
					$this->BDrequerimento->TransacaoLerMensagem($id_msg, $this->session->userdata('ID'));
				}
			
				$dados['tipo_requerimento'] = $this->BDrequerimento->ListarTipoRequerimento(0);

				$id_requerimento = $dados['requerimento']['id_requerimento'];

				$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id_requerimento);

				$dados['professor'] = $this->BDusuario->ListarProfessores();

				$dados['coordenador'] =  $coordenador;

				if($this->session->userdata('PERFIL') == 5 && $coordenador)
					$dados['curso_coordenador'] = $curso_coordenador;

				$dados['cidade_entidade'] = $this->BDrequerimento->getCidade($dados['requerimento']['id_cidade_entidade_estagio']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_coordenador']))
					$dados['nome_coordenador_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_coordenador']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_professor']))
					$dados['nome_professor_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_professor']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_finalizado']))
					$dados['nome_professor_anuencia_finalizado'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_finalizado']);

				if(!empty($dados['requerimento']['id_usuario_anuencia_cex']))
					$dados['nome_cex_anuencia'] = $this->BDusuario->getNome($dados['requerimento']['id_usuario_anuencia_cex']);

				$dados['usuarios_secretaria'] = $this->BDusuario->ListarUsuariosCEX($dados['requerimento']['id_curso'], $dados['requerimento']['id_usuario_professor']);

				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
			
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_estagio_visualizar', $dados);
				$this->load->view('main_footer');
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}	

		public function visualizar($id, $id_msg = 0){
		
			$permissao = 0;

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEditar($id);
			
			if($this->session->userdata('PERFIL') <= 4) 
				$permissao = 1;			//se for o administrador ... secretaria
			elseif($this->session->userdata('PERFIL') == 7) 
				$permissao = 1;			//se for biblioteca
			elseif($this->session->userdata('PERFIL') == 5){

				$curso_usuario = $dados['requerimento']['id_curso'];
				$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
				
				foreach($curso_coordenador as $c){
					if ($c['curso'] == $curso_usuario){
						$permissao =  1;
					}
				}

			}elseif($this->session->userdata('ID') == $dados['requerimento']['id_usuario'])
				$permissao = 1;			//se for aluno
			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				if($id_msg){
					$this->BDrequerimento->TransacaoLerMensagem($id_msg, $this->session->userdata('ID'));
				}
			
				$dados['tipo_requerimento'] = $this->BDrequerimento->ListarTipoRequerimento(0);
				$dados['mensagens'] = $this->BDrequerimento->ListarMensagensRequerimento($id);
				$dados['usuarios_secretaria'] = $this->BDusuario->ListarUsuariosSecretaria($dados['requerimento']['id_curso']);

				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
			
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_geral_visualizar', $dados);
				$this->load->view('main_footer');
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}

		public function listar_nada_consta_concedidos(){
		
			$permissao = 0;
			
			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 7) ) 
				$permissao = 1;		//se for o administrador, biblioteca
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				$dados['requerimento'] = $this->BDrequerimento->ListarBuscarNadaConstaConcedidos($this->session->userdata('PERFIL'), $this->session->userdata('ID'));

				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
			
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_nadaconsta_listar', $dados);
				$this->load->view('main_footer');
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}
  
	public function listar_requerimentos_estagio(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 2) || ($this->session->userdata('PERFIL') == 5) || ($this->session->userdata('PERFIL') == 6) || ($this->session->userdata('PERFIL') == 8) || ($this->session->userdata('PERFIL') == 9) || ($this->session->userdata('PROF') == 1) ) 
			$permissao = 1;		//se for o administrador, coordenador, professor, aluno ou cex
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){

			$dados['requerimento'] = $this->BDrequerimento->ListarBuscarRequerimentosEstagio($this->session->userdata('PERFIL'), $this->session->userdata('ID'), $this->session->userdata('PROF') );

			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_estagio_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function listar_respostas(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 8) ) 
			$permissao = 1;		//se for o administrador ou competidor(aluno)
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){

			$dados['requerimento'] = $this->BDrequerimento->ListarBuscarRespostas($this->session->userdata('PERFIL'), $this->session->userdata('ID'));
		
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_respostas_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
	
	public function listar_requerimentos(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') <= 8) 
			$permissao = 1;		//se for o administrador ... aluno
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			// $dados['requerimento'] = $this->BDrequerimento->ListarBuscarRequerimentos($this->session->userdata('PERFIL'), $this->session->userdata('ID'));

			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			// $this->load->view('requerimento_listar_buscar', $dados);
			$this->load->view('requerimento_listar_buscar_ajax');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
  
	public function listar_tipos(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1) 
			$permissao = 1;		//se for o administrador 
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['tipo'] = $this->BDrequerimento->ListarTipoRequerimento();

			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('requerimento_tipo_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function listar_requerimentos_ajax(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') <= 8) 
			$permissao = 1;		//se for o administrador ... aluno
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){

			$requerimentos = $this->BDrequerimento->ListarBuscarRequerimentosAjax($_GET, $this->session->userdata('PERFIL'), $this->session->userdata('ID'));

			header('Content-Type: application/json');

			echo json_encode($requerimentos);
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function enviar_resposta(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 8) ){ 
			$permissao = 1;
		}

		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('enviar_resposta');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
		
	}

	public function gravar_resposta(){
		
		$permissao = 0;

		if ($this->session->userdata('PERFIL') == 8){
			if($this->input->post('codigo') == $this->session->userdata('ID'))
				$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			$regras = array(
							array(
								'field' => 'questao',
								'label' => 'Questão',
								'rules' => 'trim|required'
								),						  									
			
							array(
								'field' => 'linguagem',
								'label' => 'Linguagem',
								'rules' => 'trim|required'
								),

							);
										
			$this->form_validation->set_rules($regras);
				
			
			if($this->form_validation->run() == FALSE)
			{
		
				$this->load->view('error');
				
			}
			else
			{

				//faz upload do anexo				
				$config['upload_path']          = './uploads/';
				$config['allowed_types']        = '*';
				$config['encrypt_name']			= TRUE;
				$config['max_size']             = 5120;
				
				$this->load->library('upload', $config);

				if(!empty($_FILES['userfile']['name'])){

					$_FILES['file']['name'] = $_FILES['userfile']['name'];
					$_FILES['file']['type'] = $_FILES['userfile']['type'];
					$_FILES['file']['tmp_name'] = $_FILES['userfile']['tmp_name'];
					$_FILES['file']['error'] = $_FILES['userfile']['error'];
					$_FILES['file']['size'] = $_FILES['userfile']['size'];
					
					if (!$this->upload->do_upload('file'))
					{
						$error = array('error' => $this->upload->display_errors());

						$this->load->view('error_file', $error);
					}
					else
					{

						//cria vetor para encaminhar informações
					
						$dados = array(
							'id_usuario_envio'		=> $this->input->post('codigo'),
							'questao_envio'			=> $this->input->post('questao'),
							'linguagem_envio'		=> $this->input->post('linguagem'),
							'nome_arquivo_envio'	=> $this->upload->data('file_name'),
							'caminho_completo_envio'=> $this->upload->data('full_path'),
							'tipo_arquivo_envio'	=> $this->upload->data('file_type'),
							'data_hora_envio'		=> date('Y-m-d H:i:s'),
						);
						
						$id = $this->BDrequerimento->TransacaoGravarResposta($dados);

						$retorno["msg"] = "Resposta enviada com sucesso!";
					
						$this->load->view('success_desabilita_gravar', $retorno);
						
					}

				}else{
					$error = array('error' => "Arquivo não anexado");
					$this->load->view('error_file', $error);
				}
							
			}
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}

	public function gravar_editar_resposta(){
		
		$permissao = 0;

		if ($this->session->userdata('PERFIL') == 1){
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			$regras = array(
							array(
								'field' => 'status',
								'label' => 'Status',
								'rules' => 'trim|required'
								),
							);
										
			$this->form_validation->set_rules($regras);
				
			
			if($this->form_validation->run() == FALSE)
			{
		
				$this->load->view('error');
				
			}
			else
			{

				//cria vetor para encaminhar informações
			
				$dados = array(
					'status'						=> $this->input->post('status'),
					'data_hora_resposta_envio'		=> date('Y-m-d H:i:s'),
				);
				
				$id = $this->BDrequerimento->TransacaoGravarEditarResposta($this->input->post('codigo'), $dados);

				$retorno["msg"] = "Resposta editada com sucesso!";
			
				$this->load->view('success_desabilita_gravar', $retorno);
						
			}
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


		
		public function gravar_estagio(){
		
			$permissao = 0;

			//administrador, NAE (secretaria geral), aluno e CEX
			
			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 9) ){ 
				$permissao = 1;
			}elseif ($this->session->userdata('PERFIL') == 8){
				if($this->input->post('codigo') == $this->session->userdata('ID'))
					$permissao = 1;
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			$regras = array(
							array(
									'field' => 'codigo',
									'label' => 'Nome',
									'rules' => 'trim|required'
									),
							array(
									'field' => 'data_nascimento',
									'label' => 'Data de Nascimento',
									'rules' => 'trim|required|max_length[10]'
									),						  									
							array(
									'field' => 'cpf',
									'label' => 'CPF',
									'rules' => 'trim|required|max_length[14]'
									),						  									
							array(
									'field' => 'rg',
									'label' => 'RG (identidade)',
									'rules' => 'trim|required|max_length[20]'
									),						  													
							array(
									'field' => 'curso',
									'label' => 'Curso',
									'rules' => 'trim|required'
									),						  									
							array(
									'field' => 'modalidade',
									'label' => 'Modalidade',
									'rules' => 'trim|required'
									),						  									
							array(
									'field' => 'modulo_serie',
									'label' => 'Módulo/Série',
									'rules' => 'trim|required'
									),	
							array(
									'field' => 'turno',
									'label' => 'Turno',
									'rules' => 'trim|required'
									),
								array(
								'field' => 'periodo_inicio_curso',
								'label' => 'Período de início do curso',
								'rules' => 'trim|required'
								),	
		
							array(
									'field' => 'tipo_requerimento',
									'label' => 'Tipo de Requerimento',
									'rules' => 'trim|required'
									),	
							array(
								'field' => 'execucao',
								'label' => 'Execução de Estágio',
								'rules' => 'required'
							),				  									
		
							array(
								'field' => 'q1_radio',
								'label' => 'Tipo de estágio',
								'rules' => 'required'
							),				  									

							array(
								'field' => 'q2_radio',
								'label' => 'Você está cursando alguma disciplina?',
								'rules' => 'required'
							),				  									

							array(
								'field' => 'nome_entidade',
								'label' => 'Nome da entidade concedente de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'cidade_entidade',
								'label' => 'Cidade/UF da entidade concedente de estágio',
								'rules' => 'required'
							),				  									

							array(
								'field' => 'nome_responsavel_entidade',
								'label' => 'Nome do responsável pelo contato de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'cargo_responsavel_entidade',
								'label' => 'Cargo do responsável pelo contato de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'email_entidade',
								'label' => 'E-mail da entidade concedente de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'setor_estagio',
								'label' => 'Setor/Unidade de estágio',
								'rules' => 'required'
							),		
							
							array(
								'field' => 'nome_supervisor_estagio',
								'label' => 'Nome do supervisor de estágio (empresa/instituição)',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'habilitacao_supervisor_estagio',
								'label' => 'Habilitação/formação do supervisor de estágio',
								'rules' => 'trim|required'
							),				  									
							
							array(
								'field' => 'prof_orientador_estagio',
								'label' => 'Nome do professor orientador de estágio',
								'rules' => 'required'
							),				  									

							array(
								'field' => 'data_inicio_estagio',
								'label' => 'Data prevista para início de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'data_termino_estagio',
								'label' => 'Data prevista para término de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'carga_horaria_estagio',
								'label' => 'Carga horária semanal de estágio (Horas)',
								'rules' => 'trim|required'
							),				  									

							array(
								'field' => 'atividades_estagio',
								'label' => 'Atividades principais a serem desenvolvidas no estágio',
								'rules' => 'trim|required'
							),				  									

							array(
									'field' => 'observacoes',
									'label' => 'Observações',
									'rules' => 'trim|required'
									)
							);
										
				$this->form_validation->set_rules($regras);
				
			
			if($this->form_validation->run() == FALSE)
				{
			
					$this->load->view('error');
					
				}
			else
			{
			
					//cria vetor para encaminhar informações
				
					$agora = date("Y-m-d H:i:s");
					$prazo = $this->BDrequerimento->PrazoRequerimento($this->input->post('tipo_requerimento'));
					$nada_consta = $this->BDrequerimento->NadaConstaBiblioteca($this->input->post('tipo_requerimento'));
					$autoriza_menor = $this->BDrequerimento->AutorizaRetiradaMenor($this->input->post('tipo_requerimento'));
				
					$dados_requerimento = array(
						'id_usuario_requerimento'	=> $this->input->post('codigo'),
						'id_tipo_requerimento'		=> $this->input->post('tipo_requerimento'),
						'id_curso_usuario_requerimento'	=> $this->input->post('curso'),
						'observacoes_requerimento'	=> $this->input->post('observacoes'),
						'nada_consta_bib'			=> $nada_consta,
						'data_hora_requerimento'	=> $agora,
						'data_hora_atualizacao_requerimento'	=> $agora
					);
					
					if($prazo > 0){
						require_once("dias_uteis.php");
						$dados_requerimento['data_previsao_entrega_requerimento'] = somar_dias_uteis(date("Y-m-d"), intval($prazo), '');
						//$dados_requerimento['data_previsao_entrega_requerimento'] = date("Y-m-d", strtotime("+".$prazo." days",strtotime($agora)));
					}					
					
					if(!$autoriza_menor){
						if($this->BDfuncao->VerificaIdade($this->BDfuncao->AjustaData($this->input->post('data_nascimento'))) < 18)
							$dados_requerimento['menor_idade'] = 1;
					}
				
					$dados = array(
						'data_nasc_usuario' => $this->BDfuncao->AjustaData($this->input->post('data_nascimento')),
						'cpf_usuario'		=> $this->input->post('cpf'),
						'rg_usuario'		=> $this->input->post('rg'),
						'id_curso_usuario'	=> $this->input->post('curso'),
						'id_curso_modalidade_usuario' 	=> $this->input->post('modalidade'),
						'modulo_serie_curso_usuario'	=> $this->input->post('modulo_serie'),
						'turno_curso_usuario'			=> $this->input->post('turno')
					);

					if($this->input->post('sexo'))
						$dados['sexo_usuario'] = $this->input->post('sexo');
					
					if($this->input->post('telefone'))
						$dados['telefone_usuario'] = $this->input->post('telefone');
					
					if($this->input->post('whatsapp'))
						$dados['whatsapp_usuario'] = $this->input->post('whatsapp');

					if($this->input->post('endereco_estagiario'))
						$dados['endereco_usuario'] = $this->input->post('endereco_estagiario');						

					if($this->input->post('cep_estagiario'))
						$dados['cep_usuario'] = $this->input->post('cep_estagiario');						

					if($this->input->post('cidade_estagiario'))
						$dados['cidade_usuario'] = $this->input->post('cidade_estagiario');		
					
					$id = $this->BDrequerimento->TransacaoGravarRequerimento($dados, $dados_requerimento, $this->input->post('codigo'));

					$dados_requerimento_estagio = array(
						'id_requerimento'				=> $id,
						'id_usuario_aluno'				=> $this->input->post('codigo'),
						'id_usuario_prof_orientador'	=> $this->input->post('prof_orientador_estagio'),
						'id_curso'						=> $this->input->post('curso'),
						'id_tipo_requerimento'			=> $this->input->post('tipo_requerimento'),
						'execucao_estagio'				=> $this->input->post('execucao'),
						'status_requerimento_estagio'	=> "Aguardando declaração de matrícula (Secretaria)",
						'tipo_estagio_obrigatorio'		=> $this->input->post('q1_radio'),
						'cursando_disciplinas'			=> $this->input->post('q2_radio'),
						'periodo_inicio_curso'			=> $this->input->post('periodo_inicio_curso'),
						'nome_entidade_estagio'			=> $this->input->post('nome_entidade'),
						'id_cidade_entidade_estagio'	=> $this->input->post('cidade_entidade'),
						'nome_responsavel_entidade_estagio'	=> $this->input->post('nome_responsavel_entidade'),
						'cargo_responsavel_entidade_estagio'=> $this->input->post('cargo_responsavel_entidade'),
						'email_entidade_estagio'		=> $this->input->post('email_entidade'),
						'setor_estagio'					=> $this->input->post('setor_estagio'),
						'nome_supervisor_estagio'		=> $this->input->post('nome_supervisor_estagio'),
						'habilitacao_supervisor_estagio'=> $this->input->post('habilitacao_supervisor_estagio'),
						'data_prevista_inicio_estagio'	=> $this->BDfuncao->AjustaData($this->input->post('data_inicio_estagio')),
						'data_prevista_termino_estagio'	=> $this->BDfuncao->AjustaData($this->input->post('data_termino_estagio')),
						'carga_horaria_semanal_estagio'	=> $this->input->post('carga_horaria_estagio'),
						'atividades_principais_estagio'	=> $this->input->post('atividades_estagio'),
						'autenticacao_digital'			=> sha1($id . $this->input->post('codigo') . $this->input->post('curso') . $agora),
						'data_hora'						=> $agora,
						'data_hora_atualizacao'			=> $agora
					);

					if($this->input->post('periodo_termino_disciplinas'))
						$dados_requerimento_estagio['periodo_termino_disciplinas'] = $this->input->post('periodo_termino_disciplinas');
					
					if($this->input->post('seguro_ifnmg'))
						$dados_requerimento_estagio['solicita_seguro_ifnmg'] = 1;

					if($this->input->post('seguradora_apolice'))
						$dados_requerimento_estagio['seguradora_apolice_seguro_estagio'] = $this->input->post('seguradora_apolice');

					if($this->input->post('numero_apolice_seguro'))
						$dados_requerimento_estagio['numero_apolice_seguro_estagio'] = $this->input->post('numero_apolice_seguro');

					if($this->input->post('data_inicio_apolice'))
						$dados_requerimento_estagio['data_inicio_vigencia_apolice_seguro'] = $this->BDfuncao->AjustaData($this->input->post('data_inicio_apolice'));

					if($this->input->post('data_termino_apolice'))
						$dados_requerimento_estagio['data_termino_vigencia_apolice_seguro'] = $this->BDfuncao->AjustaData($this->input->post('data_termino_apolice'));

					if($this->input->post('endereco_entidade'))
						$dados_requerimento_estagio['endereco_entidade_estagio'] = $this->input->post('endereco_entidade');

					if($this->input->post('telefone_entidade'))
						$dados_requerimento_estagio['telefone_entidade_estagio'] = $this->input->post('telefone_entidade');

					if($this->input->post('celular_entidade'))
						$dados_requerimento_estagio['celular_entidade_estagio'] = $this->input->post('celular_entidade');

					if($this->input->post('cep_entidade'))
						$dados_requerimento_estagio['cep_entidade_estagio'] = $this->input->post('cep_entidade');

					if($this->input->post('cnpj_entidade'))
						$dados_requerimento_estagio['cnpj_entidade_estagio'] = $this->input->post('cnpj_entidade');

					if($this->input->post('hora_inicio1_estagio'))
						$dados_requerimento_estagio['hora_inicio1_estagio'] = $this->input->post('hora_inicio1_estagio');

					if($this->input->post('hora_fim1_estagio'))
						$dados_requerimento_estagio['hora_fim1_estagio'] = $this->input->post('hora_fim1_estagio');

					if($this->input->post('hora_inicio2_estagio'))
						$dados_requerimento_estagio['hora_inicio2_estagio'] = $this->input->post('hora_inicio2_estagio');

					if($this->input->post('hora_fim2_estagio'))
						$dados_requerimento_estagio['hora_fim2_estagio'] = $this->input->post('hora_fim2_estagio');

					if($this->input->post('remuneracao_radio'))
						$dados_requerimento_estagio['remuneracao_radio'] = $this->input->post('remuneracao_radio');

					if($this->input->post('valor_remuneracao'))
						$dados_requerimento_estagio['valor_remuneracao'] = $this->input->post('valor_remuneracao');

					if($this->input->post('auxilio_transporte'))
						$dados_requerimento_estagio['auxilio_transporte'] = $this->input->post('auxilio_transporte');

					$id_estagio = $this->BDrequerimento->TransacaoGravarRequerimentoEstagio($dados_requerimento_estagio);

					$retorno["msg"] = "Requerimento protocolado com sucesso!<br/><strong>IMPORTANTE</strong>: Você deverá aguardar a declaração de matrícula da secretaria e, em seguida, anexar os documentos de estágio (assinados pelos componentes externos ao IFNMG e digitalizados) neste requerimento. <br/><strong>Documentos necessários</strong>: plano de estágio e termo de compromisso de estágio. No caso de estágio presencial, será necessário anexar a declaração de salubridade. Para alunos menores de idade, será necessário também anexar a autorização dos pais e/ou responsáveis.<br/><br/> <a href='".site_url('requerimento/gerarPDF/').$id_estagio."' target='_blank' style='padding: 3px 10px; background-color: #fff; color: #00A65A; border-radius: 2px; text-decoration: inherit;'><i class='fa fa-download' style='margin-right: 5px;'></i> Fazer download dos documentos iniciais do estágio</a> ";
				
					$this->load->view('success_desabilita_gravar', $retorno);

			}
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}
			
		}

	public function gravar(){
	
			$permissao = 0;
			
			if( ($this->session->userdata('PERFIL') <= 5) ){ 
				$permissao = 1;
			}elseif ($this->session->userdata('PERFIL') == 8){
				if ($this->input->post('codigo') == $this->session->userdata('ID'))
					$permissao = 1;
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			   $regras = array(
							  array(
									'field' => 'codigo',
									'label' => 'Nome',
									'rules' => 'trim|required'
									),
							  array(
									'field' => 'data_nascimento',
									'label' => 'Data de Nascimento',
									'rules' => 'trim|required|max_length[10]'
									),						  									
							  array(
									'field' => 'cpf',
									'label' => 'CPF',
									'rules' => 'trim|required|max_length[14]'
									),						  									
							  array(
									'field' => 'rg',
									'label' => 'RG (identidade)',
									'rules' => 'trim|required|max_length[20]'
									),						  													
							  array(
									'field' => 'curso',
									'label' => 'Curso',
									'rules' => 'trim|required'
									),						  									
							  array(
									'field' => 'modalidade',
									'label' => 'Modalidade',
									'rules' => 'trim|required'
									),						  									
							  array(
									'field' => 'modulo_serie',
									'label' => 'Módulo/Série',
									'rules' => 'trim|required'
									),	
							  array(
									'field' => 'turno',
									'label' => 'Turno',
									'rules' => 'trim|required'
									),
							  array(
									'field' => 'tipo_requerimento',
									'label' => 'Tipo de Requerimento',
									'rules' => 'trim|required'
									),						  									
							  array(
									'field' => 'observacoes',
									'label' => 'Descrição/Justificativa/Especificações',
									'rules' => 'trim|required'
									)
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
			
					//cria vetor para encaminhar informações
				   
					$agora = date("Y-m-d H:i:s");
					$prazo = $this->BDrequerimento->PrazoRequerimento($this->input->post('tipo_requerimento'));
					$nada_consta = $this->BDrequerimento->NadaConstaBiblioteca($this->input->post('tipo_requerimento'));
					$autoriza_menor = $this->BDrequerimento->AutorizaRetiradaMenor($this->input->post('tipo_requerimento'));
				   
					$dados_requerimento = array(
						'id_usuario_requerimento'	=> $this->input->post('codigo'),
						'id_tipo_requerimento'		=> $this->input->post('tipo_requerimento'),
						'id_curso_usuario_requerimento'	=> $this->input->post('curso'),
						'observacoes_requerimento'	=> $this->input->post('observacoes'),
						'nada_consta_bib'			=> $nada_consta,
						'data_hora_requerimento'	=> $agora,
						'data_hora_atualizacao_requerimento'	=> $agora
					);
					
					if($prazo > 0){
						require_once("dias_uteis.php");
						$dados_requerimento['data_previsao_entrega_requerimento'] = somar_dias_uteis(date("Y-m-d"), intval($prazo), '');
						//$dados_requerimento['data_previsao_entrega_requerimento'] = date("Y-m-d", strtotime("+".$prazo." days",strtotime($agora)));
					}					
					
					if(!$autoriza_menor){
						if($this->BDfuncao->VerificaIdade($this->BDfuncao->AjustaData($this->input->post('data_nascimento'))) < 18)
							$dados_requerimento['menor_idade'] = 1;
					}
				   
				    $dados = array(
						'data_nasc_usuario' => $this->BDfuncao->AjustaData($this->input->post('data_nascimento')),
						'cpf_usuario'		=> $this->input->post('cpf'),
						'rg_usuario'		=> $this->input->post('rg'),
						'id_curso_usuario'	=> $this->input->post('curso'),
						'id_curso_modalidade_usuario' 	=> $this->input->post('modalidade'),
						'modulo_serie_curso_usuario'	=> $this->input->post('modulo_serie'),
						'turno_curso_usuario'			=> $this->input->post('turno')
					);
	
					if($this->input->post('sexo'))
						$dados['sexo_usuario'] = $this->input->post('sexo');
					
					if($this->input->post('telefone'))
						$dados['telefone_usuario'] = $this->input->post('telefone');
					
					if($this->input->post('whatsapp'))
						$dados['whatsapp_usuario'] = $this->input->post('whatsapp');
					
					
					$id = $this->BDrequerimento->TransacaoGravarRequerimento($dados, $dados_requerimento, $this->input->post('codigo'));

					$retorno["msg"] = "Requerimento protocolado com sucesso!";
				   
					$this->load->view('success_desabilita_gravar', $retorno);

			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}
			
	}
  
	public function gravar_tipo(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1)){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				 
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			 $regras = array(
						array(
								'field' => 'desc_tipo_requerimento',
								'label' => 'Descricao do Tipo de Requerimento',
								'rules' => 'trim|required|max_length[100]'
								),						  									
							array(
								'field' => 'prazo_tipo_requerimento',
								'label' => 'Prazo do Tipo de Requerimento',
								'rules' => 'trim|required|max_length[03]'
								),						  									
							array(
								'field' => 'nada_consta_bib_requerimento',
								'label' => 'Nada Consta Biblioteca',
								'rules' => 'trim|required'
								),						  													
							array(
								'field' => 'autoriza_retirada_menor',
								'label' => 'Autoriza Retirada Menor',
								'rules' => 'trim|required'
								),						  									
							array(
								'field' => 'ativo_tipo_requerimento',
								'label' => 'Ativo',
								'rules' => 'trim|required'
								)
							);
									
			$this->form_validation->set_rules($regras);
			
			 
			 if($this->form_validation->run() == FALSE)
				{
			 
				$this->load->view('error');
				
			}
			 else
			 {
		
				//cria vetor para encaminhar informações
				  
				$dados = array(
					'desc_tipo_requerimento'	=> $this->input->post('desc_tipo_requerimento'),
					'prazo_tipo_requerimento'		=> $this->input->post('prazo_tipo_requerimento'),
					'nada_consta_bib_requerimento'	=> $this->input->post('nada_consta_bib_requerimento'),
					'autoriza_retirada_menor'	=> $this->input->post('autoriza_retirada_menor'),
					'ativo_tipo_requerimento'	=> $this->input->post('ativo_tipo_requerimento'),
				);
				
				$id = $this->BDtipo->Criar($dados);

				$retorno["msg"] = "Cadastro efetuado com sucesso!";
				 
				$this->load->view('success', $retorno);

			 }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}

	public function gravar_visualizar(){
	
		$permissao = 0;

		$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEditar($this->input->post('codigo'));
		
		if($this->session->userdata('PERFIL') <= 4) 
			$permissao = 1;			//se for o administrador ... secretaria
		elseif($this->session->userdata('PERFIL') == 7) 
			$permissao = 1;			//se for biblioteca
		elseif($this->session->userdata('PERFIL') == 5){

			$curso_usuario = $dados['requerimento']['id_curso'];
			$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
			
			foreach($curso_coordenador as $c){
				if ($c['curso'] == $curso_usuario){
					$permissao =  1;
				}
			}

		}elseif($this->session->userdata('ID') == $dados['requerimento']['id_usuario'])
			$permissao = 1;			//se for aluno

		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'codigo',
								'label' => 'Código do Requerimento',
								'rules' => 'trim|required'
								),
						  );
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   
				//faz upload do anexo
				$dados_doc = array();
				
				$config['upload_path']          = './uploads/';
				$config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
				$config['encrypt_name']			= TRUE;
				$config['max_size']             = 5120;
				
				$this->load->library('upload', $config);
				
				if(!empty($_FILES['docfile']['name'])){
					
					$anexosQuant = count($_FILES['docfile']['name']);
						
					for($x = 0; $x < $anexosQuant; $x++){
					
						$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
						$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
						$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
						$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
						$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
						
						if (!$this->upload->do_upload('file'))
						{
							$error = array('error' => $this->upload->display_errors());

							$this->load->view('error_file', $error);
						}
						else
						{
							$dados_doc[] = array(
								'id_requerimento'	=> $this->input->post('codigo'),
								'id_usuario_aluno'	=> $this->input->post('id_usuario'),
								'id_usuario_enviado'	=> $this->session->userdata('ID'),
								'id_curso'			=> $this->input->post('id_curso'),
								'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
								'nome_arquivo' => $this->upload->data('file_name'),
								'caminho_completo' => $this->upload->data('full_path'),
								'tipo_arquivo' => $this->upload->data('file_type')									
							);
							
						}
						
					}
					
				}				   
						
				$id = $this->BDrequerimento->TransacaoGravarEditarRequerimento($this->input->post('codigo'), array(), $dados_doc);

				$retorno["msg"] = "Requerimento alterado com sucesso!";
			   
				$this->load->view('success_reset', $retorno);

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


		public function gravar_editar(){
		
				$permissao = 0;
				
				if( ($this->session->userdata('PERFIL') <= 4) ){ 
					$permissao = 1;
				}
				
				if( ($this->session->userdata('LOGON')) && ($permissao) ){
					
					//VERIFICAR REGRAS QUE SERAO UTILIZADAS
					
				$regras = array(
								array(
										'field' => 'codigo',
										'label' => 'Nome',
										'rules' => 'trim|required'
										),
								array(
										'field' => 'data_previsao_entrega',
										'label' => 'Previsão de Entrega',
										'rules' => 'trim|required|max_length[10]'
										),
								array(
										'field' => 'observacoes',
										'label' => 'Descrição/Justificativa/Especificações',
										'rules' => 'trim|required'
										)
								);
											
					$this->form_validation->set_rules($regras);
					
				
				if($this->form_validation->run() == FALSE)
					{
				
						$this->load->view('error');
						
					}
				else
				{
					
						//faz upload do anexo
						$dados_doc = array();
						
						$config['upload_path']          = './uploads/';
						$config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
						$config['encrypt_name']			= TRUE;
						$config['max_size']             = 5120;
						
						$this->load->library('upload', $config);
						
						if(!empty($_FILES['docfile']['name'])){
							
							$anexosQuant = count($_FILES['docfile']['name']);
								
							for($x = 0; $x < $anexosQuant; $x++){
							
								$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
								$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
								$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
								$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
								$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
								
								if (!$this->upload->do_upload('file'))
								{
									$error = array('error' => $this->upload->display_errors());

									$this->load->view('error_file', $error);
								}
								else
								{
									$dados_doc[] = array(
										'id_requerimento'	=> $this->input->post('codigo'),
										'id_usuario_aluno'	=> $this->input->post('id_usuario'),
										'id_usuario_enviado'	=> $this->session->userdata('ID'),
										'id_curso'			=> $this->input->post('id_curso'),
										'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
										'nome_arquivo' => $this->upload->data('file_name'),
										'caminho_completo' => $this->upload->data('full_path'),
										'tipo_arquivo' => $this->upload->data('file_type')									
									);
									
								}
								
							}
							
						}				   
				
						//cria vetor para encaminhar informações
						
						$nada_consta = $this->BDrequerimento->NadaConstaBiblioteca($this->input->post('tipo_requerimento'));					
				
						$dados_requerimento = array(
							'id_tipo_requerimento'		=> $this->input->post('tipo_requerimento'),
							'status_requerimento'	=> $this->input->post('status'),
							'observacoes_requerimento'	=> $this->input->post('observacoes'),
							'nada_consta_bib'			=> $nada_consta,
							'data_previsao_entrega_requerimento' => $this->BDrequerimento->AjustaData($this->input->post('data_previsao_entrega')),
							'data_hora_atualizacao_requerimento'	=> date("Y-m-d H:i:s")
						);

						//se for matrícula de estágio
						if($this->input->post('tipo_requerimento') == 17){

							//se status do requerimento for finalizado ou entregue, altera status do requerimento de estágio
							if( ($this->input->post('status') == "Finalizado") || ($this->input->post('status') == "Entregue") ){
								$this->BDrequerimento->EditarRequerimentoEstagio($this->input->post('codigo'), array('declaracao_matricula' => 1, 'data_hora_atualizacao' => date("Y-m-d H:i:s")));
							}else{
								$this->BDrequerimento->EditarRequerimentoEstagio($this->input->post('codigo'), array('declaracao_matricula' => 0, 'data_hora_atualizacao' => date("Y-m-d H:i:s")));
							}

						}
		
						
						$id = $this->BDrequerimento->TransacaoGravarEditarRequerimento($this->input->post('codigo'), $dados_requerimento, $dados_doc);

						$retorno["msg"] = "Requerimento alterado com sucesso!";
					
						$this->load->view('success_desabilita_gravar', $retorno);

				}
					
				}
				else{
				
					$msg['erro'] = "Acesso negado.";

					$this->load->view('login', $msg);			
					
				}
				
		}
  
	public function gravar_editar_tipo(){
		
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				 
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			 $regras = array(
							array(
								'field' => 'desc_tipo_requerimento',
								'label' => 'Descrição do Tipo de Requerimento',
								'rules' => 'trim|required|max_length[100]'
								),
								array(
									'field' => 'prazo_tipo_requerimento',
									'label' => 'Prazo do Tipo de Requerimento',
									'rules' => 'trim|required|max_length[03]'
								),
							array(
								'field' => 'nada_consta_bib_requerimento',
								'label' => 'Nada Consta Biblioteca',
								'rules' => 'trim|required'
								),
								array(
									'field' => 'autoriza_retirada_menor',
									'label' => 'Autiraza Retirada Menor',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'ativo_tipo_requerimento',
									'label' => 'Ativo',
									'rules' => 'trim|required'
								),
							);
									
			$this->form_validation->set_rules($regras);
			
			 
			 if($this->form_validation->run() == FALSE)
				{
			 
				$this->load->view('error');
				
			}
			 else
			 {			   
		
				//cria vetor para encaminhar informações					
		
				$dados = array(
					'desc_tipo_requerimento' => $this->input->post('desc_tipo_requerimento'),
					'prazo_tipo_requerimento'	=> $this->input->post('prazo_tipo_requerimento'),
					'nada_consta_bib_requerimento' => $this->input->post('nada_consta_bib_requerimento'),
					'autoriza_retirada_menor' => $this->input->post('autoriza_retirada_menor'),
					'ativo_tipo_requerimento'	=>  $this->input->post('ativo_tipo_requerimento'),
				);
				
				$id = $this->BDtipo->Editar($this->input->post('codigo'), $dados);
	
				$retorno["msg"] = "Cadastro alterado com sucesso!";
				 
				$this->load->view('success', $retorno);
	
			 }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
	
			$this->load->view('login', $msg);			
			
		}
		
	}  

	public function gravar_editar_estagio(){
	
		$permissao = 0;

		//administrador e CEX
		
		if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 9) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'codigo',
								'label' => 'Nome',
								'rules' => 'trim|required'
								),

						array(
							'field' => 'periodo_inicio_curso',
							'label' => 'Período de início do curso',
							'rules' => 'trim|required'
							),	
	
							array(
								'field' => 'tipo_requerimento',
								'label' => 'Tipo de Requerimento',
								'rules' => 'trim|required'
								),	

							array(
								'field' => 'execucao',
								'label' => 'Execução de Estágio',
								'rules' => 'required'
							),				  									
	
							array(
								'field' => 'q1_radio',
								'label' => 'Tipo de estágio',
								'rules' => 'required'
							),				  									

							array(
							'field' => 'q2_radio',
							'label' => 'Você está cursando alguma disciplina?',
							'rules' => 'required'
						),				  									

							array(
								'field' => 'nome_entidade',
								'label' => 'Nome da entidade concedente de estágio',
								'rules' => 'trim|required'
							),				  									

							array(
							'field' => 'cidade_entidade',
							'label' => 'Cidade/UF da entidade concedente de estágio',
							'rules' => 'required'
						),				  									

						array(
							'field' => 'nome_responsavel_entidade',
							'label' => 'Nome do responsável pelo contato de estágio',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'cargo_responsavel_entidade',
							'label' => 'Cargo do responsável pelo contato de estágio',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'email_entidade',
							'label' => 'E-mail da entidade concedente de estágio',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'setor_estagio',
							'label' => 'Setor/Unidade de estágio',
							'rules' => 'required'
						),		
						
						array(
							'field' => 'nome_supervisor_estagio',
							'label' => 'Nome do supervisor de estágio (empresa/instituição)',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'habilitacao_supervisor_estagio',
							'label' => 'Habilitação/formação do supervisor de estágio',
							'rules' => 'trim|required'
						),				  									
						
						array(
							'field' => 'prof_orientador_estagio',
							'label' => 'Nome do professor orientador de estágio',
							'rules' => 'required'
						),				  									

						array(
							'field' => 'data_inicio_estagio',
							'label' => 'Data prevista para início de estágio',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'data_termino_estagio',
							'label' => 'Data prevista para término de estágio',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'carga_horaria_estagio',
							'label' => 'Carga horária semanal de estágio (Horas)',
							'rules' => 'trim|required'
						),				  									

						array(
							'field' => 'atividades_estagio',
							'label' => 'Atividades principais a serem desenvolvidas no estágio',
							'rules' => 'trim|required'
						)

					);
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   
				//faz upload do anexo
				$dados_doc = array();
				
				$config['upload_path']          = './uploads/';
				$config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
				$config['encrypt_name']			= TRUE;
				$config['max_size']             = 5120;
				
				$this->load->library('upload', $config);
				
				if(!empty($_FILES['docfile']['name'])){
					
					$anexosQuant = count($_FILES['docfile']['name']);
						
					for($x = 0; $x < $anexosQuant; $x++){
					
						$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
						$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
						$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
						$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
						$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
						
						if (!$this->upload->do_upload('file'))
						{
							$error = array('error' => $this->upload->display_errors());

							$this->load->view('error_file', $error);
						}
						else
						{
							$dados_doc[] = array(
								'id_requerimento'	=> $this->input->post('id_requerimento'), //alterado para adequar ao id requerimento principal
								'id_usuario_aluno'	=> $this->input->post('id_usuario'),
								'id_usuario_enviado'	=> $this->session->userdata('ID'),
								'id_curso'			=> $this->input->post('id_curso'),
								'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
								'nome_arquivo' => $this->upload->data('file_name'),
								'caminho_completo' => $this->upload->data('full_path'),
								'tipo_arquivo' => $this->upload->data('file_type')									
							);
							
						}
						
					}
					
				}				   
		
				//cria vetor para encaminhar informações
				$dados_requerimento_estagio = array(
					'status_requerimento_estagio'	=> $this->input->post('status_requerimento'),
					'id_usuario_prof_orientador'	=> $this->input->post('prof_orientador_estagio'),
					'execucao_estagio'				=> $this->input->post('execucao'),
					'tipo_estagio_obrigatorio'		=> $this->input->post('q1_radio'),
					'cursando_disciplinas'			=> $this->input->post('q2_radio'),
					'periodo_inicio_curso'			=> $this->input->post('periodo_inicio_curso'),
					'nome_entidade_estagio'			=> $this->input->post('nome_entidade'),
					'id_cidade_entidade_estagio'	=> $this->input->post('cidade_entidade'),
					'nome_responsavel_entidade_estagio'	=> $this->input->post('nome_responsavel_entidade'),
					'cargo_responsavel_entidade_estagio'=> $this->input->post('cargo_responsavel_entidade'),
					'email_entidade_estagio'		=> $this->input->post('email_entidade'),
					'setor_estagio'					=> $this->input->post('setor_estagio'),
					'nome_supervisor_estagio'		=> $this->input->post('nome_supervisor_estagio'),
					'habilitacao_supervisor_estagio'=> $this->input->post('habilitacao_supervisor_estagio'),
					'data_prevista_inicio_estagio'	=> $this->BDfuncao->AjustaData($this->input->post('data_inicio_estagio')),
					'data_prevista_termino_estagio'	=> $this->BDfuncao->AjustaData($this->input->post('data_termino_estagio')),
					'carga_horaria_semanal_estagio'	=> $this->input->post('carga_horaria_estagio'),
					'atividades_principais_estagio'	=> $this->input->post('atividades_estagio'),
					'data_hora_atualizacao'			=> date("Y-m-d H:i:s")
				);

				if($this->input->post('periodo_termino_disciplinas'))
					$dados_requerimento_estagio['periodo_termino_disciplinas'] = $this->input->post('periodo_termino_disciplinas');
				
				if($this->input->post('seguradora_apolice'))
					$dados_requerimento_estagio['seguradora_apolice_seguro_estagio'] = $this->input->post('seguradora_apolice');

				if($this->input->post('numero_apolice_seguro'))
					$dados_requerimento_estagio['numero_apolice_seguro_estagio'] = $this->input->post('numero_apolice_seguro');

				if($this->input->post('data_inicio_apolice'))
					$dados_requerimento_estagio['data_inicio_vigencia_apolice_seguro'] = $this->BDfuncao->AjustaData($this->input->post('data_inicio_apolice'));

				if($this->input->post('data_termino_apolice'))
					$dados_requerimento_estagio['data_termino_vigencia_apolice_seguro'] = $this->BDfuncao->AjustaData($this->input->post('data_termino_apolice'));

				if($this->input->post('endereco_entidade'))
					$dados_requerimento_estagio['endereco_entidade_estagio'] = $this->input->post('endereco_entidade');

				if($this->input->post('telefone_entidade'))
					$dados_requerimento_estagio['telefone_entidade_estagio'] = $this->input->post('telefone_entidade');

				if($this->input->post('celular_entidade'))
					$dados_requerimento_estagio['celular_entidade_estagio'] = $this->input->post('celular_entidade');

				////////////////////////////////////////

				if($this->input->post('cep_entidade'))
					$dados_requerimento_estagio['cep_entidade_estagio'] = $this->input->post('cep_entidade');
				else
					$dados_requerimento_estagio['cep_entidade_estagio'] = null;

				if($this->input->post('cnpj_entidade'))
					$dados_requerimento_estagio['cnpj_entidade_estagio'] = $this->input->post('cnpj_entidade');
				else
					$dados_requerimento_estagio['cnpj_entidade_estagio'] = null;

				if($this->input->post('hora_inicio1_estagio'))
					$dados_requerimento_estagio['hora_inicio1_estagio'] = $this->input->post('hora_inicio1_estagio');
				else
					$dados_requerimento_estagio['hora_inicio1_estagio'] = null;

				if($this->input->post('hora_fim1_estagio'))
					$dados_requerimento_estagio['hora_fim1_estagio'] = $this->input->post('hora_fim1_estagio');
				else
					$dados_requerimento_estagio['hora_fim1_estagio'] = null;

				if($this->input->post('hora_inicio2_estagio'))
					$dados_requerimento_estagio['hora_inicio2_estagio'] = $this->input->post('hora_inicio2_estagio');
				else
					$dados_requerimento_estagio['hora_inicio2_estagio'] = null;

				if($this->input->post('hora_fim2_estagio'))
					$dados_requerimento_estagio['hora_fim2_estagio'] = $this->input->post('hora_fim2_estagio');
				else
					$dados_requerimento_estagio['hora_fim2_estagio'] = null;

				if($this->input->post('remuneracao_radio'))
					$dados_requerimento_estagio['remuneracao_radio'] = $this->input->post('remuneracao_radio');
				else
					$dados_requerimento_estagio['remuneracao_radio'] = null;

				if($this->input->post('valor_remuneracao'))
					$dados_requerimento_estagio['valor_remuneracao'] = $this->input->post('valor_remuneracao');
				else
					$dados_requerimento_estagio['valor_remuneracao'] = null;

				if($this->input->post('auxilio_transporte'))
					$dados_requerimento_estagio['auxilio_transporte'] = $this->input->post('auxilio_transporte');
				else
					$dados_requerimento_estagio['auxilio_transporte'] = null;


				$id_estagio = $this->input->post('codigo');
				
				$id = $this->BDrequerimento->TransacaoGravarEditarRequerimentoEstagio($this->input->post('id_requerimento'), $dados_requerimento_estagio, $dados_doc);

				$retorno["msg"] = "Requerimento alterado com sucesso!";
			   
				$this->load->view('success_desabilita_gravar', $retorno);

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}

	public function gravar_editar_matricula(){
	
		$permissao = 0;

		//administrador e secretarias
		
		if( ($this->session->userdata('PERFIL') <= 4) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			$regras = array(
				array(
						'field' => 'id_usuario',		//id do usuário (nome do aluno)
						'label' => 'Nome',
						'rules' => 'trim|required'
						),

				array(
					'field' => 'sexo',
					'label' => 'Sexo',
					'rules' => 'trim|required'
					),						  									

				array(
					'field' => 'nacionalidade',
					'label' => 'Nacionalidade',
					'rules' => 'trim|required'
					),						  									

				array(
					'field' => 'naturalidade',
					'label' => 'Naturalidade',
					'rules' => 'trim|required'
					),						  									

				array(
						'field' => 'data_nascimento',
						'label' => 'Data de Nascimento',
						'rules' => 'trim|required|max_length[10]'
						),						  									
				array(
						'field' => 'cpf',
						'label' => 'CPF',
						'rules' => 'trim|required|max_length[14]'
						),		
						
				/*
				array(
						'field' => 'rg',
						'label' => 'RG (identidade)',
						'rules' => 'trim|required|max_length[20]'
						),	
						
				array(
					'field' => 'orgao_expedidor_rg',
					'label' => 'Órgão Expedidor (RG)',
					'rules' => 'trim|required'
					),		
					
				array(
					'field' => 'data_expedicao_rg',
					'label' => 'Data de Expedição (RG)',
					'rules' => 'trim|required|max_length[10]'
					),	
				*/					  									

				array(
					'field' => 'estado_civil',
					'label' => 'Estado Civil',
					'rules' => 'trim|required'
					),		
						
				array(
					'field' => 'cor_raca',
					'label' => 'Cor/Raça',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'deficiencia_radio',
					'label' => 'Você possui alguma deficiência?',
					'rules' => 'trim|required'
					),	
					
				array(
					'field' => 'renda_familiar_percapita',
					'label' => 'Qual é sua renda familiar per capita?',
					'rules' => 'trim|required'
					),

				array(
					'field' => 'endereco_usuario',
					'label' => 'Endereço Completo',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'cidade_usuario',
					'label' => 'Cidade/UF (Discente)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'instituicao_anterior',
					'label' => 'Instituição/Escola (Curso Anterior)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'modalidade_curso_anterior',
					'label' => 'Modalidade (Curso Anterior)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'periodo_curso_anterior',
					'label' => 'Período em Curso (Curso Anterior)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'ano_conclusao_curso_anterior',
					'label' => 'Ano de Conclusão (Curso Anterior)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'cidade_curso_anterior',
					'label' => 'Cidade/UF (Curso Anterior)',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'forma_ingresso',
					'label' => 'Forma de Ingresso',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'forma_ingresso2',
					'label' => 'Discente ingressante por',
					'rules' => 'trim|required'
					),		

				array(
					'field' => 'frequentou_if_radio',
					'label' => 'Frequenta, frequentou ou concluiu algum nesse IF?',
					'rules' => 'trim|required'
					),		
						
				array(
						'field' => 'curso',
						'label' => 'Curso',
						'rules' => 'trim|required'
						),						  									
				array(
						'field' => 'modalidade',
						'label' => 'Modalidade',
						'rules' => 'trim|required'
						),						  									
				array(
						'field' => 'modulo_serie',
						'label' => 'Módulo/Série',
						'rules' => 'trim|required'
						),	
				array(
						'field' => 'turno',
						'label' => 'Turno',
						'rules' => 'trim|required'
						),

				array(
						'field' => 'tipo_requerimento',
						'label' => 'Tipo de Requerimento',
						'rules' => 'trim|required'
						),	
				);
							
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   
				//faz upload do anexo
				$dados_doc = array();
				
				$config['upload_path']          = './uploads/';
				$config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
				$config['encrypt_name']			= TRUE;
				$config['max_size']             = 5120;
				
				$this->load->library('upload', $config);
				
				if(!empty($_FILES['docfile']['name'])){
					
					$anexosQuant = count($_FILES['docfile']['name']);
						
					for($x = 0; $x < $anexosQuant; $x++){
					
						$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
						$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
						$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
						$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
						$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
						
						if (!$this->upload->do_upload('file'))
						{
							$error = array('error' => $this->upload->display_errors());

							$this->load->view('error_file', $error);
						}
						else
						{
							$dados_doc[] = array(
								'id_requerimento'	=> $this->input->post('id_requerimento'), //alterado para adequar ao id requerimento principal
								'id_usuario_aluno'	=> $this->input->post('id_usuario'),
								'id_usuario_enviado'	=> $this->session->userdata('ID'),
								'id_curso'			=> $this->input->post('id_curso'),
								'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
								'nome_arquivo' => $this->upload->data('file_name'),
								'caminho_completo' => $this->upload->data('full_path'),
								'tipo_arquivo' => $this->upload->data('file_type')									
							);
							
						}
						
					}
					
				}			
				
				////////////////////////////////////////
				
				$dados = array(
					'nacionalidade'		=> $this->input->post('nacionalidade'),
					'naturalidade'		=> $this->input->post('naturalidade'),
					'data_nasc_usuario' => $this->BDfuncao->AjustaData($this->input->post('data_nascimento')),
					'cpf_usuario'		=> $this->input->post('cpf'),
					'rg_usuario'		=> $this->input->post('rg'),
					'orgao_expedidor_rg'=> $this->input->post('orgao_expedidor_rg'),
					'data_expedicao_rg' => $this->BDfuncao->AjustaData($this->input->post('data_expedicao_rg')),
					'estado_civil'		=> $this->input->post('estado_civil'),
					'cor_raca'			=> $this->input->post('cor_raca'),
					'deficiencia_radio'	=> $this->input->post('deficiencia_radio'),
					'renda_familiar_percapita' => $this->input->post('renda_familiar_percapita'),
					'endereco_usuario'	=> $this->input->post('endereco_usuario'),
					'cidade_usuario'	=> $this->input->post('cidade_usuario'),
					'id_curso_usuario'	=> $this->input->post('curso'),
					'id_curso_modalidade_usuario' 	=> $this->input->post('modalidade'),
					'modulo_serie_curso_usuario'	=> $this->input->post('modulo_serie'),
					'turno_curso_usuario'			=> $this->input->post('turno'),
					'sexo_usuario'					=> $this->input->post('sexo'),
					'filiacao_pai'					=> $this->input->post('filiacao_pai'),
					'filiacao_mae'					=> $this->input->post('filiacao_mae'),
					'titulo_eleitor'				=> $this->input->post('titulo_eleitor'),
					'titulo_eleitor_zona'			=> $this->input->post('titulo_eleitor_zona'),
					'titulo_eleitor_secao'			=> $this->input->post('titulo_eleitor_secao'),
					'certidao_nascimento_casamento' => $this->input->post('certidao_nascimento_casamento'),
					'deficiencia_especifica'		=> $this->input->post('deficiencia_especifica'),
					'telefone_usuario'				=> $this->input->post('telefone'),
					'whatsapp_usuario'				=> $this->input->post('whatsapp'),
				);				
				
				// $id = $this->BDrequerimento->TransacaoGravarRequerimento($dados, $dados_requerimento, $this->input->post('codigo'));

				$dados_requerimento_matricula = array(
					// 'id_requerimento'				=> $this->input->post('id_requerimento'),
					// 'id_usuario_aluno'				=> $this->input->post('id_usuario'),
					'id_curso'						=> $this->input->post('curso'),
					// 'id_tipo_requerimento'			=> $this->input->post('tipo_requerimento'),
					'instituicao_anterior'			=> $this->input->post('instituicao_anterior'),
					'modalidade_curso_anterior'		=> $this->input->post('modalidade_curso_anterior'),
					'periodo_curso_anterior'		=> $this->input->post('periodo_curso_anterior'),
					'ano_conclusao_curso_anterior'	=> $this->input->post('ano_conclusao_curso_anterior'),
					'cidade_curso_anterior'			=> $this->input->post('cidade_curso_anterior'),
					'forma_ingresso'				=> $this->input->post('forma_ingresso'),
					'forma_ingresso2'				=> $this->input->post('forma_ingresso2'),
					'frequentou_if_radio'			=> $this->input->post('frequentou_if_radio'),
					'data_hora_atualizacao'			=> date("Y-m-d H:i:s"),
					'forma_ingresso_outra_justificativa' 	=> $this->input->post('forma_ingresso_outra_justificativa'),
					'forma_ingresso_outra_justificativa2'	=> $this->input->post('forma_ingresso_outra_justificativa2'),
					'instituicao_transferencia'				=> $this->input->post('instituicao_transferencia'),
					'curso_transferencia'					=> $this->input->post('curso_transferencia'),
					'cidade_uf_transferencia'				=> $this->input->post('cidade_uf_transferencia'),
					'modalidade_frequentou_if'				=> $this->input->post('modalidade_frequentou_if'),
					'curso_frequentou_if'					=> $this->input->post('curso_frequentou_if'),
				);

				if($this->input->post('doc_historico_certificado'))
					$dados_requerimento_matricula['doc_historico_certificado'] = 1;
				else
					$dados_requerimento_matricula['doc_historico_certificado'] = 0;

				if($this->input->post('doc_documento_identificacao'))
					$dados_requerimento_matricula['doc_documento_identificacao'] = 1;
				else
					$dados_requerimento_matricula['doc_documento_identificacao'] = 0;

				if($this->input->post('doc_cpf'))
					$dados_requerimento_matricula['doc_cpf'] = 1;
				else
					$dados_requerimento_matricula['doc_cpf'] = 0;

				if($this->input->post('doc_foto'))
					$dados_requerimento_matricula['doc_foto'] = 1;
				else
					$dados_requerimento_matricula['doc_foto'] = 0;

				if($this->input->post('doc_quitacao_militar'))
					$dados_requerimento_matricula['doc_quitacao_militar'] = 1;
				else
					$dados_requerimento_matricula['doc_quitacao_militar'] = 0;

				if($this->input->post('doc_comprov_residencia'))
					$dados_requerimento_matricula['doc_comprov_residencia'] = 1;
				else
					$dados_requerimento_matricula['doc_comprov_residencia'] = 0;

				if($this->input->post('doc_cartao_sus'))
					$dados_requerimento_matricula['doc_cartao_sus'] = 1;
				else
					$dados_requerimento_matricula['doc_cartao_sus'] = 0;

				/*
				//desabilitado para fazer verificação automática do questionário
				if($this->input->post('doc_form_socioeconomico'))
					$dados_requerimento_matricula['doc_form_socioeconomico'] = 1;
				else
					$dados_requerimento_matricula['doc_form_socioeconomico'] = 0;
				*/

				if($this->input->post('doc_certidao_nascimento'))
					$dados_requerimento_matricula['doc_certidao_nascimento'] = 1;
				else
					$dados_requerimento_matricula['doc_certidao_nascimento'] = 0;

				if($this->input->post('doc_quitacao_eleitoral'))
					$dados_requerimento_matricula['doc_quitacao_eleitoral'] = 1;
				else
					$dados_requerimento_matricula['doc_quitacao_eleitoral'] = 0;

				if($this->input->post('doc_responsavel'))
					$dados_requerimento_matricula['doc_responsavel'] = 1;
				else
					$dados_requerimento_matricula['doc_responsavel'] = 0;

				$status = array('status_requerimento' => $this->input->post('status'));

				$id_matricula = $this->BDrequerimento->TransacaoGravarEditarRequerimentoMatricula($this->input->post('id_requerimento'), $this->input->post('id_usuario'), $this->input->post('atendimento_curso'), $dados, $dados_requerimento_matricula, $dados_doc, $status);

				$retorno["msg"] = "Requerimento alterado com sucesso!";
			   
				$this->load->view('success_desabilita_gravar', $retorno);	

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


	public function gravar_visualizar_matricula(){
	
		$permissao = 0;

		//administrador, secretarias e aluno
		
		if( ($this->session->userdata('PERFIL') <= 4) ){ 
			$permissao = 1;
		}

		if( ($this->session->userdata('PERFIL') == 8) ){
			if($this->input->post('id_usuario') == $this->session->userdata('ID'))
				$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			$regras = array(
				array(
						'field' => 'codigo',		//id do usuário (nome do aluno)
						'label' => 'Código do requerimento de matrícula',
						'rules' => 'trim|required'
						),

				);
							
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   
				//faz upload do anexo
				$dados_doc = array();
				
				$config['upload_path']          = './uploads/';
				// $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
				$config['allowed_types']        = 'pdf';
				$config['encrypt_name']			= TRUE;
				$config['max_size']             = 5120;
				
				$this->load->library('upload', $config);
				
				if(!empty($_FILES['docfile']['name'])){
					
					$anexosQuant = count($_FILES['docfile']['name']);
						
					for($x = 0; $x < $anexosQuant; $x++){
					
						$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
						$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
						$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
						$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
						$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
						
						if (!$this->upload->do_upload('file'))
						{
							$error = array('error' => $this->upload->display_errors());

							$this->load->view('error_file', $error);
						}
						else
						{
							$dados_doc[] = array(
								'id_requerimento'	=> $this->input->post('id_requerimento'), //alterado para adequar ao id requerimento principal
								'id_usuario_aluno'	=> $this->input->post('id_usuario'),
								'id_usuario_enviado'	=> $this->session->userdata('ID'),
								'id_curso'			=> $this->input->post('id_curso'),
								'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
								'nome_arquivo' => $this->upload->data('file_name'),
								'caminho_completo' => $this->upload->data('full_path'),
								'tipo_arquivo' => $this->upload->data('file_type')									
							);
							
						}
						
					}
					
				}			
				
				$id_matricula = $this->BDrequerimento->TransacaoGravarVisualizarRequerimentoMatricula($this->input->post('atendimento_curso'), $dados_doc);

				$retorno["msg"] = "Requerimento alterado com sucesso!";
			   
				$this->load->view('success_reset', $retorno);	

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


		public function gravar_visualizar_estagio(){
		
			$permissao = 1;

			if ($this->session->userdata('PERFIL') == 8){
				if($this->input->post('id_usuario') != $this->session->userdata('ID'))
					$permissao = 0;
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			$regras = array(
							array(
									'field' => 'codigo',
									'label' => 'Nome',
									'rules' => 'trim|required'
							),
							array(
								'field' => 'id_requerimento',
								'label' => 'ID Requerimento',
								'rules' => 'trim|required'
								)
						);
										
				$this->form_validation->set_rules($regras);
				
			
			if($this->form_validation->run() == FALSE)
				{
			
					$this->load->view('error');
					
				}
			else
			{
				
					//faz upload do anexo
					$dados_doc = array();
					
					$config['upload_path']          = './uploads/';
					$config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf|doc|docx';
					$config['encrypt_name']			= TRUE;
					$config['max_size']             = 5120;
					
					$this->load->library('upload', $config);
					
					if(!empty($_FILES['docfile']['name'])){
						
						$anexosQuant = count($_FILES['docfile']['name']);
							
						for($x = 0; $x < $anexosQuant; $x++){
						
							$_FILES['file']['name'] = $_FILES['docfile']['name'][$x];
							$_FILES['file']['type'] = $_FILES['docfile']['type'][$x];
							$_FILES['file']['tmp_name'] = $_FILES['docfile']['tmp_name'][$x];
							$_FILES['file']['error'] = $_FILES['docfile']['error'][$x];
							$_FILES['file']['size'] = $_FILES['docfile']['size'][$x];
							
							if (!$this->upload->do_upload('file'))
							{
								$error = array('error' => $this->upload->display_errors());

								$this->load->view('error_file', $error);
							}
							else
							{
								$dados_doc[] = array(
									'id_requerimento'	=> $this->input->post('id_requerimento'), //alterado para adequar ao id requerimento principal
									'id_usuario_aluno'	=> $this->input->post('id_usuario'),
									'id_usuario_enviado'	=> $this->session->userdata('ID'),
									'id_curso'			=> $this->input->post('id_curso'),
									'id_tipo_requerimento'	=> $this->input->post('tipo_requerimento'),
									'nome_arquivo' => $this->upload->data('file_name'),
									'caminho_completo' => $this->upload->data('full_path'),
									'tipo_arquivo' => $this->upload->data('file_type')									
								);
								
							}
							
						}
						
					}	

					$id_estagio = $this->input->post('codigo');

					$dados_requerimento_estagio = array('data_hora_atualizacao' => date('Y-m-d H:i:s'));
					
					$id = $this->BDrequerimento->TransacaoGravarEditarRequerimentoEstagio($this->input->post('id_requerimento'), $dados_requerimento_estagio, $dados_doc);

					$retorno["msg"] = "Requerimento alterado com sucesso!";
				
					$this->load->view('success_reset', $retorno);

			}
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}
			
		}

		public function buscaCidade(){
			
			$permissao = 1;
			
			if(isset($_POST['cidade']))
				$cidade = $_POST['cidade'];		
					
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
				if (isset($cidade))
					
					echo json_encode($this->BDrequerimento->BuscaCidade($cidade));
					
				else
				
					echo json_encode($this->BDrequerimento->BuscaCidade('Pirapora'));
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}

		public function gerarPDF($id){

			$permissao = 0;

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($id);

			//administrador, NAE (secretaria geral), aluno e CEX
			
			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 2) || ($this->session->userdata('PERFIL') == 9) ){ 
				$permissao = 1;
			}
			elseif($this->session->userdata('ID') == $dados['requerimento']['id_usuario_professor']){
				$permissao = 1;
			}
			elseif($this->session->userdata('PERFIL') == 8){

				if($this->session->userdata('ID') == $dados['requerimento']['id_usuario'])
					$permissao = 1;

			}
			if( ($this->session->userdata('PERFIL') == 5) ){
				$curso_usuario = $dados['requerimento']['id_curso'];
				$curso_coordenador = $this->BDusuario->ListaCursosCoordenador($this->session->userdata('ID'));
				
				foreach($curso_coordenador as $c){
					if ($c['curso'] == $curso_usuario){
						$permissao =  1;
					}
				}
				
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$this->all_movements($id);
				
				$html = $this->output->get_output();

				$this->pdf->loadHtml($html);
				$this->pdf->render();
				$this->pdf->stream(md5($html) . '.pdf', array("Attachment"=>1));
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}

		}

		public function gerarPlanilha(){

			error_reporting(0);		//desabilita os erros para utilizar a biblioteca phpexcel (versão antiga)

			$permissao = 0;

			//administrador e secretarias
			if( ($this->session->userdata('PERFIL') <= 4) ){ 
				$permissao = 1;
			}

			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				$dados = $this->BDrequerimento->ListarRequerimentosMatriculaPlanilha($this->session->userdata('PERFIL'));

				$this->getPlan($dados);

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}

		}

		public function gerarPlanilhaSocioEconomico(){

			error_reporting(0);		//desabilita os erros para utilizar a biblioteca phpexcel (versão antiga)

			$permissao = 0;

			//administrador e secretarias
			if( ($this->session->userdata('PERFIL') <= 4) ){ 
				$permissao = 1;
			}

			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				$dados = $this->BDrequerimento->ListarQuestionarioSocioEconomicoPlanilha($this->session->userdata('PERFIL'));

				$this->getPlan($dados);

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}

		}


		private function getPlan($dados){

			error_reporting(0);		//desabilita os erros para utilizar a biblioteca phpexcel (versão antiga)

			$this->load->helper('download');
			$this->load->library('PHPExcel');

			$planilha = $this->phpexcel;

			//gerando cabeçalho do arquivo (nomes das colunas)
			$colunas = array_keys($dados[0]);

			$alfabeto = range('A', 'Z');

			$cont = 0;
			$cont1 = 0;
			$cont2 = 0;

			foreach($colunas as $c){

				if ($cont < sizeof($alfabeto)){
					$letra = $alfabeto[$cont];
				}else{
					$letra = $alfabeto[$cont1].$alfabeto[$cont2];
					$cont2++;
					if ($cont2 >= sizeof($alfabeto)){
						$cont2 = 0;
						$cont1++;
					}
				}

				$planilha->setActiveSheetIndex(0)->setCellValue($letra.'1', $c);

				$cont++;					

			}

			//gerando os dados no arquivo

			$contador = 2;

			foreach($dados as $linha){

				$cont = 0;		//numero da coluna
				$cont1 = 0;
				$cont2 = 0;

				foreach($linha as $c){

					if ($cont < sizeof($alfabeto)){
						$letra = $alfabeto[$cont];
					}else{
						$letra = $alfabeto[$cont1].$alfabeto[$cont2];
						$cont2++;
						if ($cont2 >= sizeof($alfabeto)){
							$cont2 = 0;
							$cont1++;
						}
					}

					$planilha->setActiveSheetIndex(0)->setCellValue($letra.$contador, $c);

					$cont++;

				}

				$contador++;

			}

			$planilha->getActiveSheet()->setTitle('Planilha 1');

			$nome_arquivo = md5($this->session->userdata('ID'));

			$arquivo = './planilhas/'.$nome_arquivo.'.xlsx';

			$objgravar = PHPExcel_IOFactory::createWriter($planilha, 'Excel2007');
			$objgravar->save($arquivo);
			
			force_download($arquivo, NULL);

		}

		public function gerarPDFmatricula($id){

			$permissao = 0;

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

			//administrador e secretaria geral
			if( ($this->session->userdata('PERFIL') <= 2) ){ 
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
				$permissao = 1;
			}

			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				// $this->load->helper('download');
				
				$this->geraDocs($id);
				
				$html = $this->output->get_output();

				$this->pdf->loadHtml($html);
				$this->pdf->render();
				$this->pdf->stream(md5($html) . '.pdf', array("Attachment"=>1));
				
				// force_download(md5($html) . '.html', $html);

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}

		}

		private function geraDocs($id) {

			$dados = array();

			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);

			$menor_idade = 0;

			if($this->BDfuncao->VerificaIdade($this->BDfuncao->AjustaData($dados['requerimento']['data_nasc_usuario'])) < 18){
				$menor_idade = 1;
			}

			if($dados['requerimento']['naturalidade']){
				$dados['naturalidade'] = $this->BDrequerimento->getCidade($dados['requerimento']['naturalidade']);
			}else{
				$dados['naturalidade'] = "";
			}

			if($dados['requerimento']['cidade_usuario']){
				$dados['cidade_usuario'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_usuario']);
			}else{
				$dados['cidade_usuario'] = "";
			}


			if($dados['requerimento']['cidade_curso_anterior']){
				$dados['cidade_curso_anterior'] = $this->BDrequerimento->getCidade($dados['requerimento']['cidade_curso_anterior']);
			}else{
				$dados['cidade_curso_anterior'] = "";
			}

			if($dados['requerimento']['id_curso_modalidade_usuario']){
				$dados['modalidade'] = $this->BDmodalidade->getModalidade($dados['requerimento']['id_curso_modalidade_usuario']);
			}else{
				$dados['modalidade'] = "";
			}
			
			$dados['campus']		= $this->BDfuncao->ConfigSystem();
			$dados['menor_idade'] 	= $menor_idade;
				
			$this->load->view('pdf_matricula', $dados);
		}

		private function all_movements($id) {
			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoEstagioEditar($id);

			$usuario = $this->BDusuario->PegaUsuarioEditar($dados['requerimento']['id_usuario']);

			$menor_idade = 0;

			if($this->BDfuncao->VerificaIdade($this->BDfuncao->AjustaData($usuario['data_nascimento'])) < 18){
				$menor_idade = 1;
			}

			require_once("valor_extenso.php");

			$valor_remuneracao_extenso = valorPorExtenso($dados['requerimento']['valor_remuneracao_decimal']);
			$auxilio_transporte_extenso = valorPorExtenso($dados['requerimento']['auxilio_transporte_decimal']);

			$dados = array(
				'requerimento' 					=> $this->BDrequerimento->PegaRequerimentoEstagioEditar($id),
				'prof_orientador' 				=> $this->BDusuario->getNome($dados['requerimento']['id_usuario_professor']),
				'cidade_entidade' 				=> $this->BDrequerimento->getCidade($dados['requerimento']['id_cidade_entidade_estagio']),
				'cidade_estagiario'				=> $this->BDrequerimento->getCidade($dados['requerimento']['id_cidade_estagiario']),
				'usuario'						=> $usuario,
				'curso'							=> $this->BDcurso->PegaCursoEditar($dados['requerimento']['id_curso']),
				'campus'						=> $this->BDfuncao->ConfigSystem(),
				'menor_idade'					=> $menor_idade,
				'valor_remuneracao_extenso'		=> $valor_remuneracao_extenso,
				'auxilio_transporte_extenso'	=> $auxilio_transporte_extenso,
			);
	
			$this->load->view('pdf_estagio', $dados);
		}

		public function cadastrar_socioeconomico($id){
	
			$permissao = 0;
	
			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);
	
			//administrador e secretaria geral
			if( ($this->session->userdata('PERFIL') <= 2) ){ 
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
				$permissao = 1;
			}
	
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
				$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
	
				$this->load->view('main_header', $h);
				$this->load->view('main_sidebar');
				$this->load->view('requerimento_matricula_socioeconomico_form', $dados);
				$this->load->view('main_footer');
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				
				$this->load->view('login', $msg);			
				
			}
		
		}	

		public function gravar_socioeconomico(){
		
			$permissao = 0;
	
			$id = $this->input->post('codigo');
	
			$dados['requerimento'] = $this->BDrequerimento->PegaRequerimentoMatriculaEditar($id);
	
			//administrador e secretaria geral
			if( ($this->session->userdata('PERFIL') <= 2) ){ 
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 3) && ( ($dados['requerimento']['atendimento_curso'] == "CRA") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 4) && ( ($dados['requerimento']['atendimento_curso'] == "CRE") || ($dados['requerimento']['atendimento_curso'] == "")  ) ){
				$permissao = 1;
			}elseif ( ($this->session->userdata('PERFIL') == 8) && ($dados['requerimento']['id_usuario'] == $this->session->userdata('ID')) ){
				$permissao = 1;
			}
					
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
				$regras = array(
								array(
									'field' => 'id_usuario',
									'label' => 'Nome',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'codigo',
									'label' => 'Código do requerimento de matrícula',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q1_radio',
									'label' => 'Questão 1',
									'rules' => 'trim|required'
								),

								array(
									'field' => 'q2_radio',
									'label' => 'Questão 2',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q3_radio',
									'label' => 'Questão 3',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q4_radio',
									'label' => 'Questão 4',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q5_radio',
									'label' => 'Questão 5',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q6_radio',
									'label' => 'Questão 6',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q7_radio',
									'label' => 'Questão 7',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q8_radio',
									'label' => 'Questão 8',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q9_radio',
									'label' => 'Questão 9',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q10_radio',
									'label' => 'Questão 10',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q11_radio',
									'label' => 'Questão 11',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q12_radio',
									'label' => 'Questão 12',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q13_radio',
									'label' => 'Questão 13',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q14_radio',
									'label' => 'Questão 14',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q15_radio',
									'label' => 'Questão 15',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q16_radio',
									'label' => 'Questão 16',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q17_radio',
									'label' => 'Questão 17',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q18_radio',
									'label' => 'Questão 18',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q19_radio',
									'label' => 'Questão 19',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q20_radio',
									'label' => 'Questão 20',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q21_radio',
									'label' => 'Questão 21',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q22_radio',
									'label' => 'Questão 22',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q23_radio',
									'label' => 'Questão 23',
									'rules' => 'trim|required'
								),
								array(
									'field' => 'q24_radio',
									'label' => 'Questão 24',
									'rules' => 'trim|required'
								),
								
								);
										
				$this->form_validation->set_rules($regras);
				
				
				if($this->form_validation->run() == FALSE)
				{
				
					$this->load->view('error');
					
				}
				else
				{
				
					//cria vetor para encaminhar informações
					
					$dados = array(
							'id_requerimento_matricula' => $this->input->post('codigo'),
							'id_requerimento'			=> $this->input->post('id_requerimento'),
							'id_usuario_aluno'			=> $this->input->post('id_usuario'),
							'id_curso'					=> $this->input->post('id_curso'),
							'q1'				=> $this->input->post('q1_radio'),
							'q2'				=> $this->input->post('q2_radio'),
							'q3'				=> $this->input->post('q3_radio'),
							'q4'				=> $this->input->post('q4_radio'),
							'q5'				=> $this->input->post('q5_radio'),
							'q6'				=> $this->input->post('q6_radio'),
							'q7'				=> $this->input->post('q7_radio'),
							'q8'				=> $this->input->post('q8_radio'),
							'q9'				=> $this->input->post('q9_radio'),
							'q10'				=> $this->input->post('q10_radio'),
							'q11'				=> $this->input->post('q11_radio'),
							'q12'				=> $this->input->post('q12_radio'),
							'q13'				=> $this->input->post('q13_radio'),
							'q14'				=> $this->input->post('q14_radio'),
							'q15'				=> $this->input->post('q15_radio'),
							'q16'				=> $this->input->post('q16_radio'),
							'q17'				=> $this->input->post('q17_radio'),
							'q18'				=> $this->input->post('q18_radio'),
							'q19'				=> $this->input->post('q19_radio'),
							'q20'				=> $this->input->post('q20_radio'),
							'q21'				=> $this->input->post('q21_radio'),
							'q22'				=> $this->input->post('q22_radio'),
							'q23'				=> $this->input->post('q23_radio'),
							'q24'				=> $this->input->post('q24_radio'),
							'data_hora_socio_economico' => date('Y-m-d H:i:s')
							);
						
											
					$id = $this->BDrequerimento->TransacaoGravarSocioEconomico($dados);
						
					$retorno["msg"] = "Cadastro efetuado com sucesso!";
					
					$this->load->view('success_desabilita_gravar', $retorno);
									
				}
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
					
				$this->load->view('login', $msg);			
				
			}	
	
		}	

		public function buscaRequerimentoMatriculaUsuario($id){

			$permissao = 0;

			if( ($this->session->userdata('PERFIL') == 1) || ($this->session->userdata('PERFIL') == 2) || ($this->session->userdata('PERFIL') == 3) || ($this->session->userdata('PERFIL') == 4) || ($this->session->userdata('PERFIL') == 8) ){ 
				$permissao = 1;
			}
	
			if( ($this->session->userdata('LOGON')) && ($permissao) ){

				echo $this->BDrequerimento->existeRequerimentoMatriculaUsuario($id, "2022-07-01 00:00:00");

			}
			else{
			
				$msg['erro'] = "Acesso negado.";
					
				$this->load->view('login', $msg);			
				
			}	

		}
	
}
