<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Curso extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
		//$this->load->library('pagination');
		$this->load->model('Usuario_model', 'BDusuario');
		$this->load->model('Perfil_model', 'BDperfil');
		$this->load->model('Curso_model', 'BDcurso');
		$this->load->model('Modalidade_model', 'BDmodalidade');
		$this->load->model('Funcao_model', 'BDfuncao');
		$this->load->model('Requerimento_model', 'BDrequerimento');
		$this->load->model('Tipo_model', 'BDtipo');
		
	}

	public function index()
	{
	
	}
		
	public function gravar_editar(){


			$permissao = 0;
			
			if($this->session->userdata('PERFIL') <= 2){ 
				$permissao = 1;
			}
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
				$regras = array(
					array(
						  'field' => 'nome_curso',
						  'label' => 'Nome do Curso',
						  'rules' => 'trim|required|max_length[80]'
						  ),
					array(
						  'field' => 'atendimento_curso',
						  'label' => 'Atendimento',
						  'rules' => 'trim|required'
						  ),						  
					array(
						  'field' => 'coordenador_curso',
						  'label' => 'Coordenador do Curso',
						  'rules' => 'trim|required'
						  )									
					);
							  
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {


					$dados = array(
						'nome_curso' 			=> $this->input->post('nome_curso'),
						'atendimento_curso'	=> $this->input->post('atendimento_curso'),
						'coordenador_curso'	=> $this->input->post('coordenador_curso')
					);			
			
				    $id = $this->BDcurso->TransacaoEditarCurso($this->input->post('id_curso'), $dados);
					
				    $retorno["msg"] = "Cadastro alterado com sucesso!";
				
				    $this->load->view('success_noreset', $retorno);
				 
			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				   
				$this->load->view('login', $msg);			
				
			}	
		
	}

	public function gravar_editar_modalidade(){


		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				 
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			$regras = array(
				array(
						'field' => 'desc_curso_modalidade',
						'label' => 'Descrição da Modalidade do Curso',
						'rules' => 'trim|required|max_length[80]'
						),
				array(
						'field' => 'codigo',
						'label' => 'Código da Modalidade do Curso',
						'rules' => 'trim|required'
						)								
				);
							
			$this->form_validation->set_rules($regras);
			
			 
			 if($this->form_validation->run() == FALSE)
				{
			 
				$this->load->view('error');
				
			}
			 else
			 {


				$dados = array(
					'desc_curso_modalidade' => $this->input->post('desc_curso_modalidade')
				);			
		
					$id = $this->BDmodalidade->Editar($this->input->post('codigo'), $dados);
				
					$retorno["msg"] = "Cadastro alterado com sucesso!";
			
					$this->load->view('success', $retorno);
			 
			 }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
				 
			$this->load->view('login', $msg);			
			
		}	
	
}
	
	public function editar($id){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') <= 2){ 
			$permissao = 1;
		}
	
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$dados['curso'] = $this->BDcurso->PegaCursoEditar($id);
			$dados['servidores'] = $this->BDusuario->ListarServidores();
			
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_editar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}			

	public function editar_modalidade($id){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1){ 
			$permissao = 1;
		}
	
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			
			$dados['modalidade'] = $this->BDmodalidade->Pega($id);
			
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_modalidade_editar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}			

	public function listar(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 2) ) 
			$permissao = 1;		//se for o administrador ... secretaria geral
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['curso'] = $this->BDcurso->ListarBuscarCursos();
		
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function listar_modalidade(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1;		//se for o administrador 
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['modalidade'] = $this->BDcurso->ListarModalidadeCursos();
		
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_modalidade_listar_buscar', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
	
	public function cadastrar(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') <= 2) ) 
			$permissao = 1;		//se for administrador ... secretaria geral
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			$dados['servidores'] = $this->BDusuario->ListarServidores();
			$dados['curso'] = $this->BDcurso->ListarCursos();
								
			$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_cadastrar_form', $dados);
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}

	public function cadastrar_modalidade(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1;		//se for administrador 
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
		$h['mensagens'] = $this->BDrequerimento->ListarMensagensRecebidas($this->session->userdata('ID'), $this->session->userdata('PERFIL'));
		
			$this->load->view('main_header', $h);
			$this->load->view('main_sidebar');
			$this->load->view('curso_modalidade_cadastrar_form');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
		
	public function gravar(){
	
			$permissao = 0;
			
			if( ($this->session->userdata('PERFIL') <= 2) ) 
				$permissao = 1; //se for administrador ... secretaria geral
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
				//VERIFICAR REGRAS QUE SERAO UTILIZADAS
				
			   $regras = array(
							  array(
									'field' => 'nome_curso',
									'label' => 'Nome do Curso',
									'rules' => 'trim|required|max_length[80]'
									),
							  array(
									'field' => 'atendimento_curso',
									'label' => 'Atendimento',
									'rules' => 'trim|required'
									),						  
							  array(
									'field' => 'coordenador_curso',
									'label' => 'Coordenador do Curso',
									'rules' => 'trim|required'
									)									
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
				   //cria usuario com informações repassadas
				   //cria vetor para encaminhar informações
				   
				    $dados = array(
						  'nome_curso' 			=> $this->input->post('nome_curso'),
						  'atendimento_curso'	=> $this->input->post('atendimento_curso'),
						  'coordenador_curso'	=> $this->input->post('coordenador_curso')
						);
	
	
				   $id = $this->BDcurso->TransacaoGravarCurso($dados);

				   $retorno["msg"] = "Cadastro efetuado com sucesso!";
				   
				   $this->load->view('success', $retorno);

			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";

				$this->load->view('login', $msg);			
				
			}
			
	}

	public function gravar_modalidade(){
	
		$permissao = 0;
		
		if( ($this->session->userdata('PERFIL') == 1) ) 
			$permissao = 1; //se for administrador ... secretaria geral
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				 
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
			 $regras = array(
							array(
								'field' => 'desc_curso_modalidade',
								'label' => 'Descrição da Modalidade do Curso',
								'rules' => 'trim|required|max_length[80]'
								),							
							);
									
			$this->form_validation->set_rules($regras);
			
			 
			 if($this->form_validation->run() == FALSE)
				{
			 
				$this->load->view('error');
				
			}
			 else
			 {
				 //cria usuario com informações repassadas
				 //cria vetor para encaminhar informações
				 
					$dados = array(
						'desc_curso_modalidade'	=> $this->input->post('desc_curso_modalidade')
					);


				 $id = $this->BDmodalidade->Criar($dados);

				 $retorno["msg"] = "Cadastro efetuado com sucesso!";
				 
				 $this->load->view('success', $retorno);

			 }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
}
		
}
