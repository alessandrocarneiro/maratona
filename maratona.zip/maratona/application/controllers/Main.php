<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
		$this->load->model('Usuario_model', 'BDusuario');
		$this->load->model('Requerimento_model', 'BDrequerimento');
		$this->load->model('Curso_model', 'BDcurso');
		$this->load->model('Funcao_model', 'BDfuncao');
		
	}


	public function index()
	{

	    if($this->session->userdata('LOGON')){
			
			$dados = array();
			
			$perfil = $this->session->userdata('PERFIL');
			$id = $this->session->userdata('ID');
						
			//carrega visão de usuário logado			
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('main_content', $dados);
			$this->load->view('main_footer');

		}
		else
		{
								   
		    $regras = array(
						  array(
								'field' => 'email',
								'label' => 'e-mail',
								'rules' => 'trim|required|valid_email|max_length[255]'
								),
						  array(
								'field' => 'senha',
								'label' => 'senha',
								'rules' => 'trim|required|min_length[4]|max_length[16]'
								)
						  );
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
		   {
				
				$this->load->view('login');
				
		   }
		   else
		   {
			   
				$login = $this->BDusuario->AutenticarUsuario( $this->input->post('email'), md5($this->input->post('senha')) );
				
				if(!empty($login)){
				
					if($this->input->post('remember')):
						
						$cookie = array(
									'name' => 'remember_email',
									'value' => $this->input->post('email'),
									'expire' => '86400'		#24 horas
						);
						
						$this->input->set_cookie($cookie);
						
						$cookie = array(
									'name' => 'remember_password',
									'value' => $this->input->post('senha'),
									'expire' => '86400'		#24 horas
						);
						
						$this->input->set_cookie($cookie);
						
					else:

						$cookie = array(
									'name' => 'remember_email',
									'value' => ''
						);
						
						$this->input->set_cookie($cookie);
						
						$cookie = array(
									'name' => 'remember_password',
									'value' => ''
						);
						
						$this->input->set_cookie($cookie);					
						
					endif;
					
					//registra/confirma sessao do usuario
					$this->session->set_userdata($login);
					
					$dados = array();
			
					$perfil = $this->session->userdata('PERFIL');
					$id = $this->session->userdata('ID');
										
					//carrega visão de usuário logado							
					$this->load->view('main_header');
					$this->load->view('main_sidebar');
					$this->load->view('main_content', $dados);
					$this->load->view('main_footer');
					
				}else{
					
					$msg['erro'] = "Acesso negado: e-mail e/ou senha inexistentes ou incorretos.";
				   
					$this->load->view('login', $msg);
					
				}
				
				
		   }
	   
		} //if sessao já logada	
	
	}
	
	public function logout(){
		   
		$login = array(
						'ID' 	=> '',
						'NOME' 	=> '',
						'EMAIL' => '',
						'PERFIL'=> '',
						'LOGON' => FALSE,
						'ACESSO'=> ''
						);
		
		$this->session->unset_userdata($login);
		
		$this->session->sess_destroy();

		$this->load->view('login');

	}

	public function buscaArrayConfig($id = 1){
		
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1) 
			$permissao = 1;	
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			if (isset($id))
				
				echo '[' . json_encode($this->BDfuncao->ConfigSystem($id)) . ']';
				
			else
			
				echo '[' . json_encode(array()) . ']';
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}	

	public function buscaListaUsuariosCEX(){
		
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') == 1) 
			$permissao = 1;	
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
		
			echo json_encode($this->BDusuario->ListarUsuariosCEXConfig());
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}	

	public function gravar_config_smtp(){
	
		$permissao = 0;

		//administrador
		
		if( ($this->session->userdata('PERFIL') == 1) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'host_smtp',
								'label' => 'Host SMTP',
								'rules' => 'trim|required'
								),

						array(
							'field' => 'porta_smtp',
							'label' => 'Porta SMTP',
							'rules' => 'trim|required'
							),	
	
							array(
								'field' => 'cripto_porta_smtp',
								'label' => 'Criptograffia Porta SMTP',
								'rules' => 'trim|required'
								),	

							array(
								'field' => 'usuario_smtp',
								'label' => 'Usuário SMTP',
								'rules' => 'trim|required'
							),				  									
	
							array(
								'field' => 'senha_smtp',
								'label' => 'Senha SMTP',
								'rules' => 'trim|required'
							),				  									


					);
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   		
				//cria vetor para encaminhar informações
				$dados_config = array(
					'email_smtp_config'		=> $this->input->post('usuario_smtp'),
					'senha_smtp_config'		=> $this->input->post('senha_smtp'),
					'host_smtp_config'		=> $this->input->post('host_smtp'),
					'port_smtp_config'		=> $this->input->post('porta_smtp'),
					'cripto_smtp_config'	=> $this->input->post('cripto_porta_smtp'),
				);
				
				$id = $this->BDfuncao->TransacaoGravarConfig($dados_config, 1);

				echo "Configuração salva!";

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}


	public function gravar_config_cex(){
	
		$permissao = 0;

		//administrador
		
		if( ($this->session->userdata('PERFIL') == 1) ){ 
			$permissao = 1;
		}
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
			   
			//VERIFICAR REGRAS QUE SERAO UTILIZADAS
			
		   $regras = array(
						  array(
								'field' => 'cex_id_usuario',
								'label' => 'Usuário padrão CEX',
								'rules' => 'trim|required'
								),

						array(
							'field' => 'cex_numero_apolice_ifnmg',
							'label' => 'Número da Apólice de Seguro',
							'rules' => 'trim|required'
							),	
	
							array(
								'field' => 'cex_seguradora_apolice_ifnmg',
								'label' => 'Seguradora da Apólice de Seguro',
								'rules' => 'trim|required'
								),	

					);
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
			{
		   
				$this->load->view('error');
				
			}
		   else
		   {
			   		
				//cria vetor para encaminhar informações
				$dados_config = array(
					'id_usuario_cex'			=> $this->input->post('cex_id_usuario'),
					'numero_apolice_ifnmg'		=> $this->input->post('cex_numero_apolice_ifnmg'),
					'seguradora_apolice_ifnmg'	=> $this->input->post('cex_seguradora_apolice_ifnmg'),
				);
				
				$id = $this->BDfuncao->TransacaoGravarConfig($dados_config, 1);

				echo "Configuração salva!";

		   }
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";

			$this->load->view('login', $msg);			
			
		}
		
	}

	
}
